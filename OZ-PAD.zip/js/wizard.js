let matrixData = [];
let dictionaryData = {};
let productDictionary = {};
let summaryTemplates = {};
let glossaryData = {};
let lastModalTrigger = null;
let wizardSaveBound = false;
let activeModalTrapCleanup = null;

// Lokalny akcesor pomocniczy Wizarda. Ewaluowany przy ładowaniu.
const W = window.utils || {};

/**
 * System powiadomień toast — wyświetla nieblokujące komunikaty dla użytkownika.
 * @param {string} message - Treść komunikatu.
 * @param {string} type - Typ toastu: 'success', 'error', 'warning' (domyślnie: 'success').
 * @param {number} duration - Czas wyświetlania w ms (domyślnie: 5000).
 */
function showToast(message, type = 'success', duration = 5000) {
    // Poczekaj na gotowość DOM, jeśli wywołano zbyt wcześnie
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => showToast(message, type, duration));
        return;
    }

    const container = document.getElementById('toast-container');
    if (!container) {
        console.error('Toast container (#toast-container) not found in DOM');
        return;
    }

    // Sprawdź, czy ten sam komunikat jest już wyświetlany
    const existingToasts = container.querySelectorAll('.toast-content');
    for (const t of existingToasts) {
        if (t.textContent === message) {
            // Pulsuj istniejący toast
            const parent = t.closest('.toast');
            parent.style.animation = 'none';
            parent.offsetHeight; /* trigger reflow */
            parent.style.animation = 'pulse 0.3s ease-in-out';
            return;
        }
    }

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.setAttribute('role', 'none');

    // 1. Ukryty element TYLKO dla automatycznego ogłoszenia (Live Region)
    const announcement = document.createElement('div');
    announcement.setAttribute('role', type === 'error' ? 'alert' : 'status');
    announcement.setAttribute('aria-live', type === 'error' ? 'assertive' : 'polite');
    announcement.className = 'sr-only';
    
    // 2. Struktura wizualna (ikona + tekst)
    const visualContent = document.createElement('div');
    visualContent.style.display = 'flex';
    visualContent.style.alignItems = 'center';
    visualContent.style.flex = '1';
    visualContent.setAttribute('aria-hidden', 'true'); // Ukryj przed SR przy focusie na przycisku lub kontenerze

    // Mapowanie ikon
    const icons = {
        success: 'check-circle',
        error: 'alert-circle',
        warning: 'alert-triangle'
    };
    const iconName = icons[type] || 'info';

    // Utwórz ikonę
    const icon = document.createElement('i');
    icon.setAttribute('data-lucide', iconName);
    icon.className = 'toast-icon';
    icon.style.marginRight = '0.75rem';

    // Utwórz span z treścią
    const textSpan = document.createElement('span');
    textSpan.className = 'toast-content';
    textSpan.textContent = message;

    visualContent.appendChild(icon);
    visualContent.appendChild(textSpan);

    // 3. Utwórz przycisk zamknięcia (jedyna focusowalny/słyszalny element podczas nawigacji Tab)
    const closeBtn = document.createElement('button');
    closeBtn.className = 'toast-close';
    closeBtn.setAttribute('aria-label', `Zamknij powiadomienie: ${message}`); // Link context to button
    closeBtn.setAttribute('type', 'button');
    closeBtn.innerHTML = '<i data-lucide="x" style="width: 16px; height: 16px;" aria-hidden="true"></i>';

    // Złóż toast
    toast.appendChild(announcement);
    toast.appendChild(visualContent);
    toast.appendChild(closeBtn);
    
    container.appendChild(toast);

    // Wyzwól ogłoszenie
    setTimeout(() => {
        announcement.textContent = message;
    }, 50);

    // Zainicjuj ikony Lucide w toaście
    if (window.lucide) {
        window.lucide.createIcons();
    }

    // Zapamiętaj poprzednio sfocusowany element, by przywrócić fokus po zamknięciu
    const previouslyFocused = document.activeElement;

    // Obsługa przycisku zamknięcia
    closeBtn.addEventListener('click', () => {
        toast.remove();
        // Przywróć fokus do elementu, który wywołał toast
        if (previouslyFocused && previouslyFocused !== document.body) {
            previouslyFocused.focus();
        }
    });

    // Przenieś fokus na przycisk zamknięcia zaraz po wyświetleniu
    // setTimeout zapewnia, że element jest w DOM i widoczny
    setTimeout(() => {
        closeBtn.focus();
    }, 50);
}

/**
 * Uproszczone nazwy rozdziałów do wyświetlenia w Wizardzie
 */
const chapterNames = {
    'C.5': 'Wymagania ogólne',
    'C.6': 'TIK z komunikacją głosową',
    'C.7': 'TIK z funkcją wideo',
    'C.8': 'Sprzęt (Hardware)',
    'C.9': 'Strony internetowe (Web)',
    'C.10': 'Dokumenty (Non-web)',
    'C.11': 'Oprogramowanie (Software)',
    'C.12': 'Dokumentacja i usługi wsparcia',
    'C.13': 'Usługi przekaźnikowe i alarmowe',
    'U': 'Wymagania wynikające z zapisów ustawy'
};

/**
 * Usuwa numerację techniczną z początku tytułu klauzuli (np. "9.2.1 Audio..." -> "Audio...").
 */
function stripNumbering(text) {
    if (!text) return '';
    // Usuń wiodącą numerację klauzuli. Może zawierać myślnik i cyfry (np. "C.5.3-1")
    // lub małoliterowy sufiks (np. "C.8.3.2.5.c"), więc regex musi być wystarczająco
    // liberalny, by pochłonąć cały prefiks. Po prefiksie przycinamy białe znaki.
    return text.replace(/^((?:C|U)\.[A-Za-z0-9\.-]+|[\d\.]+|[A-Z]\d+[\.\)]?)\s*/, '');
}

/**
 * Naprawia osierocone spójniki w tekście polskim (np. "a ", "i "), zastępując spację znakiem &nbsp;.
 */
function fixOrphans(text) {
    if (!text) return '';
    return text.replace(/(\s|^)([aiouwzAIOWZ])\s+/g, '$1$2\u00A0');
}

/**
 * Zwraca pełną nazwę produktu (Profil - Nazwa)
 */
function getFullProductNameWizard() {
    const resultsArea = document.getElementById('resultsArea');
    const profileName = resultsArea?.getAttribute('data-product-name') || 'Profil nieokreślony';
    const productName = document.getElementById('wizard-product-name')?.value || '';
    
    if (productName && productName !== 'Produkt/Usługa' && productName !== 'Produkt') {
        return `${profileName} - ${productName}`;
    }
    return profileName;
}

async function init() {
    try {
        // Wymuś odświeżenie plików słownikowych przy ładowaniu, by mieć najnowsze dane
        const ts = new Date().getTime();
        const [dictResp, mappingResp, summaryResp, glossaryResp] = await Promise.all([
            fetch(`clauses_json/clauses.json?t=${ts}`),
            fetch(`clauses_json/mapping.json?t=${ts}`),
            fetch(`clauses_json/summaries.json?t=${ts}`),
            fetch(`clauses_json/glossary.json?t=${ts}`)
        ]);
        
        dictionaryData = await dictResp.json();
        const mapping = await mappingResp.json();
        summaryTemplates = await summaryResp.json();
        glossaryData = await glossaryResp.json();
        
        matrixData = mapping.matrix;
        productDictionary = mapping.products;

        // Zachowaj oryginalny indeks, by utrzymać kolejność JSON w obrębie grup artykułów/kategorii
        if (Array.isArray(matrixData)) {
            matrixData.forEach((item, index) => {
                item._originalIndex = index;
            });

            matrixData.sort((a, b) => {
                const isArt19A = (a.article || "").includes("Art. 19");
                const isArt19B = (b.article || "").includes("Art. 19");
                
                if (isArt19A && !isArt19B) return 1;  // A za B
                if (!isArt19A && isArt19B) return -1; // A przed B
                
                // Najpierw spróbuj posortować wg kategorii (numerów artykułów w nich zawartych)
                const artA = (a.category || "").match(/Art\.?\s*(\d+)/);
                const artB = (b.category || "").match(/Art\.?\s*(\d+)/);
                
                if (artA && artB) {
                    const numA = parseInt(artA[1], 10);
                    const numB = parseInt(artB[1], 10);
                    if (numA !== numB) return numA - numB;
                }
                
                // Jeśli ta sama kategoria lub brak numeru art. w kategorii, wróć do oryginalnej kolejności JSON
                // (unikamy problemów z sortowaniem słownym np. "pierwsze" vs "drugie")
                return (a._originalIndex || 0) - (b._originalIndex || 0);
            });
        }

        populateRadioList();
        // Przycisk zawsze aktywny — walidacja odbywa się przy submicie
        document.getElementById('generateBtn').disabled = false;
        
        // Fokus na H1 przy starcie — wyłączone: powodowało pomijanie nagłówka
        // document.querySelector('h1').focus();
        
        // Wzbogać przyciski ikon o widoczne etykiety i ustaw stan ARIA przełączników motywu
        if (typeof updateThemeToggleButtonsWizard === 'function') updateThemeToggleButtonsWizard(document.documentElement.getAttribute('data-theme') || 'dark');
        // Upewnij się, że Lucide renderuje ikony dodane dynamicznie (przycisk zamknięcia itp.)
        try { if (typeof lucide !== 'undefined' && typeof lucide.createIcons === 'function') lucide.createIcons(); } catch (e) { /* ignore */ }
        
        // Skonfiguruj przycisk zapisu i skrót Ctrl+S
        setupWizardSave();
        setupSummaryButton();
        setupHero();
        initBrowser();
        setupHeaderScrollHandler();
    } catch (err) {
        console.error("Błąd podczas inicjalizacji:", err);
    }
}

/**
 * Inicjalizuje sekcję Hero
 */
function setupHero() {
    const heroNew = document.getElementById('hero-new-audit');
    const heroLoad = document.getElementById('hero-load-audit');
    const heroBrowse = document.getElementById('hero-browse-requirements');
    const heroSection = document.getElementById('hero-section');
    const setupSection = document.getElementById('setup-section');
    const browserSection = document.getElementById('browser-section');
    const fileInput = document.getElementById('wizard-file-input');

    if (heroNew) {
        heroNew.addEventListener('click', (e) => {
            e.preventDefault();
            // Ukryj inne sekcje jeśli otwarte
            if (browserSection) browserSection.classList.add('hidden');
            
            // Pokaż sekcję pod hero
            setupSection.classList.remove('hidden');
            
            // Wyczyść pola formularza dla nowego arkusza
            const productNameInput = document.getElementById('wizard-product-name');
            const productDescInput = document.getElementById('wizard-product-desc');
            const auditorInput = document.getElementById('wizard-auditor-name');
            if (productNameInput) productNameInput.value = '';
            if (productDescInput) productDescInput.value = '';
            if (auditorInput) auditorInput.value = '';
            
            // Wyczyść zaznaczenie radio buttonów dla produktów
            const productRadios = document.querySelectorAll('input[name="product_choice"]');
            productRadios.forEach(radio => radio.checked = false);
            
            // Ukryj komunikaty o błędach z poprzedniego formularza
            const productSelectionError = document.getElementById('product-selection-error');
            const productNameError = document.getElementById('product-name-error');
            const productDescError = document.getElementById('product-desc-error');
            const auditorError = document.getElementById('auditor-name-error');
            if (productSelectionError) {
                productSelectionError.classList.add('hidden');
                productSelectionError.style.display = 'none';
            }
            if (productNameError) {
                productNameError.classList.add('hidden');
                productNameError.style.display = 'none';
            }
            if (productDescError) {
                productDescError.classList.add('hidden');
                productDescError.style.display = 'none';
            }
            if (auditorError) {
                auditorError.classList.add('hidden');
                auditorError.style.display = 'none';
            }
            
            // Ukryj poprzednie wyniki
            const resultsArea = document.getElementById('resultsArea');
            if (resultsArea) {
                resultsArea.classList.add('hidden');
                // Nie czyścimy innerHTML bo to usuwa elementy child w DOM
            }
            
            // Przewiń do sekcji pod hero
            setTimeout(() => {
                const header = document.querySelector('.app-header');
                const headerOffset = header ? header.getBoundingClientRect().height : 0;
                const top = setupSection.getBoundingClientRect().top + window.pageYOffset - headerOffset - 20;
                window.scrollTo({ top, behavior: 'smooth' });

                // Przenieś fokus na główny tytuł arkusza
                const setupTitle = document.getElementById('setup-title');
                if (setupTitle) setupTitle.focus({ preventScroll: true });
                
                // Aktualizuj tytuł strony
                if (typeof Browser !== 'undefined' && Browser.updateTitle) {
                    Browser.updateTitle('Nowy arkusz oceny');
                }
            }, 100);
        });
    }

    if (heroLoad) {
        heroLoad.addEventListener('click', (e) => {
            e.preventDefault();
            if (fileInput) fileInput.click();
        });
    }

    if (heroBrowse) {
        heroBrowse.addEventListener('click', (e) => {
            e.preventDefault();
            // Ukryj sekcję setup jeśli otwarta
            if (setupSection) setupSection.classList.add('hidden');
            
            // Pokaż przeglądarkę
            browserSection.classList.remove('hidden');
            
            // Inicjalizacja widoku jeśli pusta
            if (typeof Browser !== 'undefined' && !Browser.initialized) {
                Browser.init();
            }
            
            // Domyślny tytuł przeglądarki po wejściu z Hero
            if (typeof Browser !== 'undefined' && Browser.updateTitle) {
                const browserViewTitle = Browser.view === 'legal' ? 
                    'Wymagania według Ustawy — Przeglądarka wymagań' : 
                    'Wymagania według Normy EN 301 549 — Przeglądarka wymagań';
                Browser.updateTitle(browserViewTitle);
            }

            // Przewiń
            setTimeout(() => {
                const header = document.querySelector('.app-header');
                const headerOffset = header ? header.getBoundingClientRect().height : 0;
                const top = browserSection.getBoundingClientRect().top + window.pageYOffset - headerOffset - 20;
                window.scrollTo({ top, behavior: 'smooth' });

                // Przenieś fokus na tytuł przeglądarki
                const browserTitle = document.getElementById('browser-title');
                if (browserTitle) browserTitle.focus({ preventScroll: true });
            }, 100);
        });
    }
}

/**
 * Globalny obiekt przeglądarki wymagań
 */
const Browser = {
    initialized: false,
    view: 'legal', // 'legal' | 'technical' (widok ustawowy lub techniczny)
    currentCategory: null,
    searchQuery: '',

    init() {
        this.initialized = true;
        this.renderCategories();
        this.setupEventListeners();
    },

    setupEventListeners() {
        const btnLegal = document.getElementById('btn-view-legal');
        const btnTechnical = document.getElementById('btn-view-technical');
        const searchInput = document.getElementById('browser-search');
        const switcher = document.querySelector('.view-switcher');

        btnLegal?.addEventListener('click', () => this.switchView('legal'));
        btnTechnical?.addEventListener('click', () => this.switchView('technical'));
        
        switcher?.addEventListener('keydown', (e) => {
            const buttons = [btnLegal, btnTechnical].filter(Boolean);
            const currentIdx = buttons.findIndex(b => b.getAttribute('aria-checked') === 'true');
            let nextIdx = -1;

            if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
                nextIdx = (currentIdx + 1) % buttons.length;
            } else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
                nextIdx = (currentIdx - 1 + buttons.length) % buttons.length;
            }

            if (nextIdx !== -1) {
                e.preventDefault();
                const nextBtn = buttons[nextIdx];
                nextBtn.focus();
                this.switchView(nextBtn.id === 'btn-view-legal' ? 'legal' : 'technical');
            }
        });

        searchInput?.addEventListener('input', (e) => {
            this.searchQuery = e.target.value.toLowerCase();
            this.search();
        });
    },

    updateTitle(pageDetail) {
        const baseTitle = 'Ocena zgodności z Polskim Aktem Dostępności';
        if (pageDetail) {
            document.title = `${pageDetail} — ${baseTitle}`;
        } else {
            document.title = baseTitle;
        }
    },

    switchView(view) {
        this.view = view;
        this.currentCategory = null;
        this.searchQuery = '';
        
        const btnLegal = document.getElementById('btn-view-legal');
        const btnTechnical = document.getElementById('btn-view-technical');
        const searchInput = document.getElementById('browser-search');

        if (searchInput) searchInput.value = '';

        if (view === 'legal') {
            btnLegal.classList.replace('outline', 'primary');
            btnLegal.setAttribute('aria-checked', 'true');
            btnLegal.setAttribute('tabindex', '0');
            btnTechnical.classList.replace('primary', 'outline');
            btnTechnical.setAttribute('aria-checked', 'false');
            btnTechnical.setAttribute('tabindex', '-1');
            this.updateTitle('Wymagania według Ustawy — Przeglądarka wymagań');
        } else {
            btnTechnical.classList.replace('outline', 'primary');
            btnTechnical.setAttribute('aria-checked', 'true');
            btnTechnical.setAttribute('tabindex', '0');
            btnLegal.classList.replace('primary', 'outline');
            btnLegal.setAttribute('aria-checked', 'false');
            btnLegal.setAttribute('tabindex', '-1');
            this.updateTitle('Wymagania według Normy EN 301 549 — Przeglądarka wymagań');
        }

        this.renderCategories();
    },

    renderCategories() {
        const grid = document.getElementById('browser-category-grid');
        const list = document.getElementById('browser-requirements-list');
        const breadcrumbs = document.getElementById('browser-breadcrumbs');
        
        grid.classList.remove('hidden');
        list.classList.add('hidden');
        breadcrumbs.classList.add('hidden');
        grid.innerHTML = '';

        let categories = [];
        if (this.view === 'legal') {
            // Kategorie ustawowe wyświetlamy w kolejności numerycznej (sortowanie odbywa się globalnie w init())
            const uniqueCats = [];
            matrixData.forEach(item => {
                if (item.category && !uniqueCats.includes(item.category)) {
                    uniqueCats.push(item.category);
                }
            });
            categories = uniqueCats.map(cat => ({ id: cat, name: cat, type: 'legal' }));
        } else {
            // Rozdziały normy EN — dynamicznie z `clauses.json` (dictionaryData)
            const chapterSet = new Set();
            Object.keys(dictionaryData).forEach(k => {
                if (!k || !k.startsWith('C.')) return;
                const parts = k.split('.');
                const chapter = parts.slice(0,2).join('.'); // e.g., C.10
                chapterSet.add(chapter);
            });

            const chapters = Array.from(chapterSet).sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));

            chapters.forEach(id => {
                categories.push({ id, name: `${id} ${chapterNames[id] || ''}`.trim(), type: 'technical' });
            });
        }

        categories.forEach(cat => {
            const li = document.createElement('li');
            const card = document.createElement('a');
            card.href = '#';
            card.className = 'browser-category-card';
            card.setAttribute('aria-label', `Przejdź do kategorii: ${cat.name}`);
            
            card.innerHTML = `
                <div class="browser-category-icon" aria-hidden="true">
                    <i data-lucide="${cat.type === 'legal' ? 'scale' : 'book-open'}" aria-hidden="true"></i>
                </div>
                <span class="browser-category-name">${cat.name}</span>
            `;

            card.addEventListener('click', (e) => {
                e.preventDefault();
                this.selectCategory(cat.id);
            });

            li.appendChild(card);
            grid.appendChild(li);
        });

        if (typeof lucide !== 'undefined') lucide.createIcons();
    },

    transformLegalRequirement(m) {
        // Główny kod klauzuli prawnej przypisany do artykułu
        const uId = m.legal_id;

        const dictEntry = (uId ? dictionaryData[uId] : null) || (m.id ? dictionaryData[m.id] : null);

        return {
            id: dictEntry?.id || uId || m.id || m.article,
            title: dictEntry?.title || m.requirement || m.article,
            procedure: dictEntry?.procedure || [],
            checklist: dictEntry?.checklist || [],
            evaluation: dictEntry?.evaluation || '',
            preconditions: dictEntry?.preconditions || [],
            form: dictEntry?.form || null,
            notes: dictEntry?.notes || [],

            // info dla createRequirementCard (wyświetlany numer artykułu i tytuł z mappingu)
            overrideId: m.article || (dictEntry && dictEntry.id) || (uId || m.id),
            overrideTitle: (m.requirement || (dictEntry && dictEntry.title) || '').replace(/\s*\([^)]+\)$/, '').trim()
        };
    },

    selectCategory(catId) {
        this.currentCategory = catId;
        this.renderRequirements();
    },

    renderRequirements() {
        const grid = document.getElementById('browser-category-grid');
        const list = document.getElementById('browser-requirements-list');
        const breadcrumbs = document.getElementById('browser-breadcrumbs');
        
        grid.classList.add('hidden');
        list.classList.remove('hidden');
        breadcrumbs.classList.remove('hidden');
        list.innerHTML = '';

        // Oznaczenie tytułu strony dla konkretnej wybranej kategorii
        const categoryLabel = (this.view === 'legal' ? '' : this.currentCategory + ' ') + (chapterNames[this.currentCategory] || this.currentCategory);
        this.updateTitle(`${categoryLabel} — Przeglądarka wymagań`);

        // Renderuj okruszki (breadcrumb)
        breadcrumbs.innerHTML = `
            <a href="#" id="browser-back-to-cats" class="browser-back-link"><span aria-hidden="true">←</span> Powrót do listy kategorii</a>
        `;

        document.getElementById('browser-back-to-cats').addEventListener('click', (e) => {
            e.preventDefault();
            this.currentCategory = null;
            this.renderCategories();
            // Przywróć tytuł widoku głównego przeglądarki
            this.updateTitle(this.view === 'legal' ? 'Wymagania według Ustawy — Przeglądarka wymagań' : 'Wymagania według Normy EN 301 549 — Przeglądarka wymagań');
        });

        // Wstaw nagłówek H2 z nazwą bieżącej kategorii dla poprawnej hierarchii nagłówków
        list.innerHTML = '<h2 id="browser-current-category" tabindex="-1" class="browser-current-category">' + (this.currentCategory + ' ' + (chapterNames[this.currentCategory] || '')).trim() + '</h2>';
        // Ustaw focus na nagłówku, aby narzędzia dostępności widziały od razu aktualny kontekst
        const catHeading = document.getElementById('browser-current-category');
        if (catHeading) catHeading.focus();

        // Filtruj słownik wg kategorii
        let reqs = [];
        if (this.view === 'legal') {
            // Budujemy listę bezpośrednio z matrixData (posortowanej numerycznie po artykułach w init())
            const matrixItems = matrixData.filter(m => m.category === this.currentCategory);
            reqs = matrixItems.map(m => this.transformLegalRequirement(m));
        } else {
            // Rozdziały techniczne (C.*)
            const chapterPrefix = this.currentCategory; // np. 'C.9'

            // Kody dostępne w clauses.json dla danego rozdziału
            const dictCodes = Object.keys(dictionaryData).filter(k => k && (k === chapterPrefix || k.startsWith(chapterPrefix + '.')));

            // Dodatkowo zbierzemy kody C.* występujące w mapping.json, by uwzględnić brakujące wpisy w clauses.json
            const mappingCodes = new Set();
            matrixData.forEach(m => {
                // Agregujemy kody techniczne tylko z product_mappings
                const combined = Object.values(m.product_mappings || {}).join(';');
                combined.split(';').map(s => s.trim()).filter(Boolean).forEach(token => {
                    if (token === chapterPrefix || token.startsWith(chapterPrefix + '.') || token.startsWith(chapterPrefix)) {
                        if (token.startsWith('C.')) mappingCodes.add(token);
                    }
                });
            });

            const allCodes = Array.from(new Set([...dictCodes, ...mappingCodes]))
                .filter(Boolean)
                .sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));

            reqs = allCodes
                .filter(code => dictionaryData[code]) // Filtrujemy kody, których nie ma w słowniku (np. nagłówki sekcji z mapping.json)
                .map(code => {
                    const dictEntry = dictionaryData[code];
                    return {
                        id: dictEntry.id || code,
                        title: dictEntry.title || code,
                        procedure: dictEntry.procedure || [],
                        checklist: dictEntry.checklist || [],
                        evaluation: dictEntry.evaluation || '',
                        preconditions: dictEntry.preconditions || [],
                        form: dictEntry.form || null,
                        notes: dictEntry.notes || []
                    };
                });
        }

        reqs.forEach(req => {
            const card = this.createRequirementCard(req);
            list.appendChild(card);
        });

        // Oznacz linki otwierające się w nowej karcie (wizualnie CSS + tekst dla SR)
        indicateNewTabLinks(list);

        if (typeof lucide !== 'undefined') lucide.createIcons();
        window.scrollTo({ top: list.getBoundingClientRect().top + window.pageYOffset - 150, behavior: 'smooth' });
    },

    createRequirementCard(req) {
        if (!req || !req.id) return document.createElement('div');
        const div = document.createElement('div');
        div.className = 'browser-card';
        
        // Funkcja pomocnicza do renderowania elementów ze standardowymi narzędziami
        const clean = (text) => {
            if (!text) return '';
            let t = text;
            if (W.stripNumbering) t = W.stripNumbering(t);
            if (W.fixOrphans) t = W.fixOrphans(t);
            // Parsuj Markdown
            if (window.utils && window.utils.parseMarkdown) {
                t = window.utils.parseMarkdown(t);
            }
            return t;
        };

        const renderListContent = (arr) => {
            if (!arr || arr.length === 0) return '';
            
            // Specjalna obsługa obiektów testów — renderuj jako interaktywne karty (widok przeglądarki)
            const hasTests = arr.some(item => item && typeof item === 'object' && item.type === 'test');
            if (hasTests) {
                return arr.map(item => {
                    if (item && typeof item === 'object' && item.type === 'test') {
                        // Użyj minimalnej karty testu (bez formularza oceny) dla przeglądarki
                        return renderTestCardMinimal(item);
                    }
                    // Parsuj Markdown dla zwykłych elementów tekstowych
                    let itemText = item || '';
                    if (W.fixOrphans) itemText = W.fixOrphans(itemText);
                    if (W.parseMarkdown) itemText = W.parseMarkdown(itemText);
                    return `<p>${itemText}</p>`;
                }).join('');
            }
            
            // Konwertuj obiekty testów na tekst dla widoków podsumowania (nie-przeglądarka)
            const stringified = arr.map(item => {
                if (item && typeof item === 'object' && item.type === 'test') {
                    let text = `**${item.title || ''}**`;
                    if (item.description) text += `: ${item.description}`;
                    return text;
                }
                return item;
            });

            // Połącz z nowym wierszem, by parseMarkdown mógł wykrywać bloki/listy
            let content = stringified.join('\n');
            if (W.fixOrphans) content = W.fixOrphans(content);
            if (W.parseMarkdown) content = W.parseMarkdown(content);

            const trimmed = content.trim();
            if (trimmed && !trimmed.startsWith('<h') && !trimmed.startsWith('<ul') && !trimmed.startsWith('<ol') && !trimmed.startsWith('<p')) {
                return `<p>${content}</p>`;
            }
            return content;
        };

        // Formatowanie ID dla wyświetlania ustawowego/technicznego
        let displayId = req.overrideId || req.id;
        
        if (!req.overrideId && req.id.startsWith('U.')) {
            const parts = req.id.split('.');
            if (parts.length >= 2) {
                displayId = `Art. ${parts[1]}`;
                if (parts[2] && parseInt(parts[2]) !== 0) displayId += ` ust. ${parts[2]}`;
                if (parts[3] && parseInt(parts[3]) !== 0) displayId += ` pkt ${parts[3]}`;
                
                if (parts[4]) {
                    const subParts = parts[4].split('-');
                    displayId += ` lit. ${subParts[0]}`;
                    if (subParts[1]) {
                        const tirets = {
                            '01': 'pierwsze', '02': 'drugie', '03': 'trzecie', 
                            '04': 'czwarte', '05': 'piąte', '06': 'szóste',
                            '07': 'siódme', '08': 'ósme', '09': 'dziewiąte', '10': 'dziesiąte'
                        };
                        displayId += ` tiret ${tirets[subParts[1]] || subParts[1]}`;
                    }
                }
            }
        }
        
        let labelsHtml = '';
        if (req.evaluation) labelsHtml += `<span class="browser-label">Metoda: ${req.evaluation}</span>`;
        if (req.id && req.id.includes('9.')) labelsHtml += `<span class="browser-label">WCAG</span>`;

        // Preconditions
        let preconditionsHtml = '';
        if (req.preconditions && req.preconditions.length > 0) {
            preconditionsHtml = `
                <div class="interpretation-area">
                    <h4 class="u-interpretation-header">Warunki wstępne</h4>
                    <section class="u-interpretation">
                        ${renderListContent(req.preconditions)}
                    </section>
                </div>
            `;
        }

        // Procedure
        let procedureHtml = '';
        if (req.procedure && req.procedure.length > 0) {
            // Label "Jak to rozumieć?" dla wszystkich treści prawnych (U. oraz A.)
            const isLegal = req.id.startsWith('U.') || req.id.startsWith('A') || (req.overrideId && req.overrideId.includes('Art'));
            const procedureLabel = isLegal ? 'Jak to rozumieć?' : 'Procedura badania:';
            procedureHtml = `
                <div class="interpretation-area">
                    <h4 class="u-interpretation-header">${procedureLabel}</h4>
                    <section class="u-interpretation">
                        ${renderListContent(req.procedure)}
                    </section>
                </div>
            `;
        }
        
        // Criteria
        let criteriaHtml = '';
        if (req.form && req.form.inputs) {
            criteriaHtml = `
                <div class="browser-criteria" style="margin-top: 1rem; padding: 0.75rem; background: rgba(0,0,0,0.03); border: 1px solid var(--muted-border-color); border-radius: 4px;">
                    <strong style="display: block; margin-bottom: 0.5rem; font-size: 0.85rem; color: var(--primary);">Kryteria sukcesu:</strong>
                    ${req.form.inputs.map(i => `<p style="margin-bottom: 0.25rem; font-size: 0.85rem;"><strong>${i.value.toUpperCase()}:</strong> ${clean(i.label)}</p>`).join('')}
                </div>
            `;
        }

        // Checklist (lista kontrolna)
        let checklistHtml = '';
        if (req.checklist && req.checklist.length > 0) {
            checklistHtml = `
                <div class="interpretation-area">
                    <h4 class="u-interpretation-header">Jak sprawdzić?</h4>
                    <div class="detailed-checklist-container">
                        ${renderListContent(req.checklist)}
                    </div>
                </div>
            `;
        }

        // Notes
        let notesHtml = '';
        if (req.notes && req.notes.length > 0) {
            notesHtml = `
                <div class="interpretation-area">
                    <h4 class="u-interpretation-header">Uwagi</h4>
                    <section class="u-interpretation">
                        ${renderListContent(req.notes)}
                    </section>
                </div>
            `;
        }

        // Clean title
        let cleanTitle = req.overrideTitle || (req.title || '').replace(req.id, '').trim();
        if (!req.overrideTitle) {
            cleanTitle = cleanTitle.replace(/\s*\([^)]+\)$/, '').trim();
        }

        div.innerHTML = `
            <div class="browser-card-header">
                <div style="width: 100%;">
                    <div class="browser-card-id">${displayId}</div>
                    <h3 style="margin: 0.5rem 0;">${cleanTitle}</h3>
                    <div class="browser-card-labels">
                        ${labelsHtml}
                    </div>
                </div>
            </div>
            <div class="browser-card-body">
                ${preconditionsHtml}
                ${procedureHtml}
                ${criteriaHtml}
                ${checklistHtml}
                ${notesHtml}
            </div>
        `;

        return div;
    },

    search() {
        const searchStatus = document.getElementById('browser-search-status');
        
        if (!this.searchQuery) {
            if (searchStatus) searchStatus.innerText = '';
            if (this.currentCategory) this.renderRequirements();
            else this.renderCategories();
            return;
        }

        const grid = document.getElementById('browser-category-grid');
        const list = document.getElementById('browser-requirements-list');
        const breadcrumbs = document.getElementById('browser-breadcrumbs');

        grid.classList.add('hidden');
        list.classList.remove('hidden');
        breadcrumbs.classList.add('hidden');
        list.innerHTML = '';

        let results = [];
        if (this.view === 'legal') {
            // Wyszukiwanie w wymaganiach prawnych (mapping.json + powiązane klauzule U.*)
            // Szukamy w pełnej treści klauzul U.* dla każdego artykułu
            results = matrixData
                .filter(m => {
                    let searchContent = (m.article + ' ' + (m.requirement || '') + ' ' + (m.category || '') + ' ' + (m.legal_id || '')).toLowerCase();
                    
                    // Dodaj kody techniczne z mapowania
                    if (m.product_mappings) {
                        searchContent += ' ' + Object.values(m.product_mappings).join(' ').toLowerCase();
                    }
                    
                    // Przeszukaj pełną treść powiązanej klauzuli U.*
                    const uId = m.legal_id;
                    const dictEntry = (uId ? dictionaryData[uId] : null) || (m.id ? dictionaryData[m.id] : null);
                    if (dictEntry) {
                        searchContent += ' ' + (dictEntry.id || '') + ' ' + (dictEntry.title || '');
                        if (dictEntry.procedure && Array.isArray(dictEntry.procedure)) {
                            searchContent += ' ' + dictEntry.procedure.join(' ');
                        } else if (dictEntry.procedure) {
                            searchContent += ' ' + dictEntry.procedure;
                        }
                        if (dictEntry.checklist && Array.isArray(dictEntry.checklist)) {
                            searchContent += ' ' + dictEntry.checklist.join(' ');
                        } else if (dictEntry.checklist) {
                            searchContent += ' ' + dictEntry.checklist;
                        }
                        if (dictEntry.notes && Array.isArray(dictEntry.notes)) {
                            searchContent += ' ' + dictEntry.notes.join(' ');
                        } else if (dictEntry.notes) {
                            searchContent += ' ' + dictEntry.notes;
                        }
                        if (dictEntry.preconditions && Array.isArray(dictEntry.preconditions)) {
                            searchContent += ' ' + dictEntry.preconditions.join(' ');
                        } else if (dictEntry.preconditions) {
                            searchContent += ' ' + dictEntry.preconditions;
                        }
                        if (dictEntry.evaluation) {
                            searchContent += ' ' + dictEntry.evaluation;
                        }
                        if (dictEntry.form && dictEntry.form.inputs) {
                            searchContent += ' ' + dictEntry.form.inputs.map(i => i.label + ' ' + i.value).join(' ');
                        }
                    }

                    return searchContent.toLowerCase().includes(this.searchQuery);
                })
                .map(m => this.transformLegalRequirement(m));
        } else {
            // Wyszukiwanie w klauzulach technicznych (clauses.json) - tylko C.* (normy techniczne)
            results = Object.values(dictionaryData).filter(req => {
                // Filtruj tylko klauzule C.* (normy techniczne), nie U.* (prawne)
                if (!req || !req.id || !req.id.startsWith('C.')) return false;
                
                // Buduj tekst do przeszukania ze wszystkich pól
                let searchContent = (req.id || '') + ' ' + (req.title || '');
                
                // Procedura
                if (req.procedure && Array.isArray(req.procedure)) {
                    searchContent += ' ' + req.procedure.join(' ');
                } else if (req.procedure) {
                    searchContent += ' ' + req.procedure;
                }
                
                // Lista kontrolna (checklist)
                if (req.checklist && Array.isArray(req.checklist)) {
                    searchContent += ' ' + req.checklist.join(' ');
                } else if (req.checklist) {
                    searchContent += ' ' + req.checklist;
                }
                
                // Notes
                if (req.notes && Array.isArray(req.notes)) {
                    searchContent += ' ' + req.notes.join(' ');
                } else if (req.notes) {
                    searchContent += ' ' + req.notes;
                }
                
                // Preconditions
                if (req.preconditions && Array.isArray(req.preconditions)) {
                    searchContent += ' ' + req.preconditions.join(' ');
                } else if (req.preconditions) {
                    searchContent += ' ' + req.preconditions;
                }
                
                // Evaluation
                if (req.evaluation) {
                    searchContent += ' ' + req.evaluation;
                }
                
                // Form criteria
                if (req.form && req.form.inputs) {
                    searchContent += ' ' + req.form.inputs.map(i => i.label + ' ' + i.value).join(' ');
                }
                
                return searchContent.toLowerCase().includes(this.searchQuery);
            });
        }

        if (searchStatus) {
            searchStatus.innerText = results.length > 0 
                ? `Znaleziono ${results.length} wyników.` 
                : 'Brak wyników dla podanej frazy.';
        }

        if (results.length === 0) {
            list.innerHTML = '<p style="text-align: center; padding: 2rem;">Brak wyników dla podanej frazy.</p>';
            return;
        }

        results.slice(0, 50).forEach(req => {
            const card = this.createRequirementCard(req);
            list.appendChild(card);
        });

        if (typeof lucide !== 'undefined') lucide.createIcons();
    }
};

/**
 * Pusta funkcja inicjalizująca - faktyczna inicjalizacja następuje w init() -> initBrowser()
 */
function initBrowser() {
    // Rejestracja globalna jeśli potrzebna
}

/**
 * Logika generowania podsumowania opisowego
 */
function setupSummaryButton() {
    const resultsArea = document.getElementById('resultsArea');
    if (!resultsArea) return;

    // Dodaj dedykowaną sekcję podsumowania na końcu wyników
    let summarySection = document.getElementById('wizard-summary-section');
    if (!summarySection) {
        summarySection = document.createElement('section');
        summarySection.id = 'wizard-summary-section';
        summarySection.className = 'summary-section-container';
        summarySection.innerHTML = `
            <div class="summary-box" style="margin-top: 3rem; padding: 0.5rem; background: transparent;">
                <div id="summary-display-area" style="width: 100%;"></div>
            </div>
        `;
        resultsArea.appendChild(summarySection);
    }

    if (typeof lucide !== 'undefined') lucide.createIcons();
}

function scrollToRequirement(targetId) {
    const element = document.getElementById(targetId);
    if (!element) return;
    
    const header = document.querySelector('.app-header');
    const headerOffset = header ? header.getBoundingClientRect().height : 0;
    const top = element.getBoundingClientRect().top + window.pageYOffset - headerOffset - 16;
    
    // Skok natychmiastowy — bez animacji (lepsza dla wrażliwości na ruch i czytników ekranu)
    window.scrollTo({ top, behavior: 'instant' });
    element.focus({ preventScroll: true });

    // Ogłoś nawigację technologiom wspomagającym przez live region
    const label = element.getAttribute('aria-label') || '';
    const announcement = document.getElementById('generation-announcement');
    if (announcement && label) {
        announcement.textContent = '';
        requestAnimationFrame(() => { announcement.textContent = `Przejście do: ${label}`; });
    }

    const originalBg = element.style.backgroundColor;
    element.style.backgroundColor = 'var(--primary-focus)';
    element.style.transition = 'background-color 0.3s';
    
    setTimeout(() => {
        element.style.backgroundColor = originalBg;
        // Wyczyść transition po zakończeniu animacji
        setTimeout(() => { element.style.transition = ''; }, 300);
    }, 2000);
}

function updateTestSummaryForRow(row) {
    const summaryDiv = row.querySelector('.test-summary-assessment');
    if (!summaryDiv) return;

    const testCards = Array.from(row.querySelectorAll('.checklist-test-item[data-test-id]'));
    const total = testCards.length;
    const evaluated = testCards.filter(card => card.querySelector('input[type="radio"]:checked'));

    if (evaluated.length === 0) {
        summaryDiv.innerHTML = '';
        return;
    }

    const failed = evaluated.filter(card => card.querySelector('input[value="fail"]:checked')).length;
    const passed = evaluated.filter(card => card.querySelector('input[value="pass"]:checked')).length;
    const na     = evaluated.filter(card => card.querySelector('input[value="na"]:checked')).length;

    const pluralTest = n => n === 1 ? 'test' : (n >= 2 && n <= 4) ? 'testy' : 'testów';

    let proposal;
    if (failed > 0) proposal = 'Niespełnione';
    else if (na === evaluated.length) proposal = 'Nie dotyczy';
    else proposal = 'Spełnione';

    const parts = [];
    if (failed > 0) parts.push(`${failed} ${pluralTest(failed)} niespełnione`);
    if (passed > 0) parts.push(`${passed} ${pluralTest(passed)} spełnione`);
    if (na     > 0) parts.push(`${na} ${pluralTest(na)} wykluczone`);

    let html = `<p>Proponowana ocena klauzuli: <strong>${proposal}</strong></p>`;
    html += `<p>Sprawdzono ${evaluated.length} z ${total} ${pluralTest(total)}: ${parts.join(', ')}.</p>`;

    summaryDiv.innerHTML = html;
}

function getAssessmentSummaryData() {
    const rows = Array.from(document.querySelectorAll('.requirement-row'));
    
    // Sprawdź czy Art. 19 jest włączony
    const art19Switch = document.querySelector('input[role="switch"]');
    const isArt19Enabled = art19Switch ? art19Switch.checked : false;
    
    // Filtruj wiersze
    const activeRows = rows.filter(row => {
        const isInArt19Container = row.closest('[data-art19-container="true"]');
        if (isInArt19Container) {
            return isArt19Enabled;
        }
        return true;
    });
    
    let passedCount = 0;
    let failedCount = 0;
    let inapplicableCount = 0;
    let untestedCount = 0;
    const totalCount = activeRows.length;
    
    const failures = [];
    const passed = [];
    const untested = [];
    const inapplicable = [];
    const incompleteAssessments = []; // klauzule z ocenionymi testami ale bez oceny klauzuli

    activeRows.forEach((row, index) => {
        // Dodaj unikalne ID do każdego wiersza dla nawigacji, jeśli jeszcze nie ma
        if (!row.id) row.id = `req-row-${index}`;
        
        const article = row.querySelector('.requirement-id span[aria-hidden="true"]')?.textContent?.trim() || '';
        const requirementText = row.querySelector('.requirement-text')?.textContent?.trim() || '';
        const safeArticleId = article.replace(/[^a-z0-9]/gi, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
        const comment = row.querySelector(`textarea[name="comment-${safeArticleId}"]`)?.value || '';
        const fullLabel = `${article} - ${requirementText}`;
        
        // Zbierz testy jednostkowe: wszystkie ocenione ORAZ te które mają komentarz
        const allTests = Array.from(row.querySelectorAll('.checklist-test-item[data-test-id]')).map(card => {
            const summary = card.querySelector('.checklist-test-summary');
            const testComment = card.querySelector('textarea')?.value || '';
            const checkedRadio = card.querySelector('input[type="radio"]:checked');
            const status = checkedRadio ? checkedRadio.value : null; // 'pass', 'fail', 'na' lub null
            
            // Zwróć test jeśli jest oceniony LUB ma komentarz
            if (status || testComment) {
                return { 
                    title: summary ? summary.textContent.trim() : '', 
                    comment: testComment,
                    status: status || 'na'
                };
            }
            return null;
        }).filter(t => t !== null);

        // Wyznacz kategorię na podstawie numeru artykułu z tekstu ("Art. 7 ust. ..." lub "Art 22 pkt ...")
        const artMatch = article.match(/Art\.?\s*(\d+)/);
        const artNum = artMatch ? parseInt(artMatch[1], 10) : 0;
        let itemCategory = '';
        if (artNum >= 7 && artNum <= 22) itemCategory = 'accessibility_requirements';
        else if ([23, 24, 26, 32, 33].includes(artNum)) itemCategory = 'service_provider_obligations';

        // Obiekt pomocniczy dla linku i danych
        const itemData = { 
            label: fullLabel, 
            article: article,
            category: itemCategory,
            requirement: requirementText,
            comment: comment,
            failedTests: allTests,
            targetId: row.id 
        };
        
        const selectedRadio = row.querySelector(`input[type="radio"][name="status-${safeArticleId}"]:checked`);

        // Sprawdź czy wiersz ma ocenione testy jednostkowe ale brak oceny klauzuli
        const hasEvaluatedTests = row.querySelector(
            '.checklist-test-item input[type="radio"]:checked'
        ) !== null;
        if (!selectedRadio && hasEvaluatedTests) {
            incompleteAssessments.push({ label: fullLabel, article, targetId: row.id });
        }

        if (!selectedRadio) {
            untestedCount++;
            untested.push(itemData);
        } else {
            const val = selectedRadio.value;
            if (val === 'compliant') {
                passedCount++;
                passed.push(itemData);
            } else if (val === 'non-compliant') {
                failedCount++;
                failures.push(itemData);
            } else {
                inapplicableCount++;
                inapplicable.push(itemData);
            }
        }
    });

    // Ustal templateKey
    let templateKey = '';
    if (untestedCount === totalCount && totalCount > 0) {
        templateKey = 'no_assessment';
    } else if (totalCount === 0) {
        templateKey = 'no_assessment';
    } else if (passedCount === 0 && failedCount === 0 && inapplicableCount > 0) {
        templateKey = (untestedCount > 0) ? 'all_inapplicable_partial' : 'all_inapplicable';
    } else {
        const isFullAudit = (untestedCount === 0);
        if (isFullAudit) {
            templateKey = failedCount > 0 ? 'non_compliance_full' : 'full_compliance';
        } else {
            templateKey = failedCount > 0 ? 'partial_compliance_failed' : 'partial_compliance_passed';
        }
    }

    return {
        passed, failures, untested, inapplicable, incompleteAssessments,
        passedCount, failedCount, untestedCount, inapplicableCount, totalCount,
        templateKey, isArt19Enabled
    };
}

function generateDescriptiveSummary(isInitial = false) {
    const resultsArea = document.getElementById('resultsArea');
    const displayArea = document.getElementById('summary-display-area');
    
    if (!displayArea) return;

    // Jeśli to inicjalizacja, pokaż tylko pustą kartę z przyciskiem
    if (isInitial) {
        let emptyHtml = `
            <article class="summary-result-card">
                <header class="summary-header initial">
                    <h2>Podsumowanie oceny</h2>
                    <button id="btn-generate-summary" class="primary" onclick="generateDescriptiveSummary()">
                        <i data-lucide="file-text" aria-hidden="true"></i> Generuj podsumowanie
                    </button>
                </header>
            </article>
        `;
        displayArea.innerHTML = emptyHtml;
        if (typeof lucide !== 'undefined') lucide.createIcons();
        return;
    }

    const fullProductName = getFullProductNameWizard();
    const summaryData = getAssessmentSummaryData();
    const { failures, passed, untested, inapplicable, incompleteAssessments, templateKey, untestedCount } = summaryData;

    const config = summaryTemplates.compliance_summaries[templateKey];
    const currentDate = new Date().toLocaleDateString('pl-PL');

    // Kolorystyka zależy od wyniku
    const inapplicableOnlyTemplate = templateKey === 'all_inapplicable' || templateKey === 'all_inapplicable_partial';
    const summaryState = (templateKey === 'no_assessment' || inapplicableOnlyTemplate) ? 'warning' : (summaryData.failedCount > 0 ? 'fail' : 'pass');

    // Dodaj informację o ocenie częściowej do statusu
    let displayStatus = config.status;
    if (templateKey !== 'no_assessment') {
        if (untestedCount > 0) {
            displayStatus += ' (ocena częściowa)';
        } else {
            displayStatus += ' (ocena pełna)';
        }
    }

    let html = `
        <article class="summary-result-card" data-state="${summaryState}">
            <header class="summary-header">
                <h2>Podsumowanie oceny</h2>
                <button id="btn-generate-summary" class="primary" onclick="generateDescriptiveSummary()">
                    <i data-lucide="refresh-cw" aria-hidden="true"></i> Aktualizuj podsumowanie
                </button>
            </header>

            <div class="summary-content-area">
                <h3 class="summary-status-title">
                    STATUS: ${displayStatus}
                </h3>
                
                <div class="summary-meta">
                    <div><strong>Data oceny:</strong> ${currentDate}</div>
                </div>

                ${incompleteAssessments.length > 0 ? `
                <div class="summary-incomplete-warning" role="alert">
                    <strong>Uwaga: brakująca ocena klauzuli</strong>
                    <p>Poniższe klauzule mają ocenione testy jednostkowe, ale nie wybrano dla nich oceny ogólnej. Uzupełnij ocenę, aby podsumowanie było kompletne.</p>
                    <ul>
                        ${incompleteAssessments.map(it => `
                        <li>
                            <a href="#${it.targetId}" onclick="event.preventDefault(); scrollToRequirement('${it.targetId}');">${it.label}</a>
                        </li>`).join('')}
                    </ul>
                </div>
                ` : ''}

                <div class="summary-body">
                    ${(() => {
                        let text = config.description.replace('{productName}', `**${fullProductName}**`);
                        if (W.parseMarkdown) text = W.parseMarkdown(text);
                        return text;
                    })()}
                </div>
    `;

    // Sekcje zawartości

    if (config.meta) {
        html += `
            <div class="summary-meta" style="margin-top: 1.5rem; padding: 1rem; border: 1px dashed var(--muted-color); border-radius: 8px;">
                <div><strong>${config.meta.date_label}:</strong> ${currentDate}</div>
                <div><strong>${config.meta.scope_label}:</strong> ${config.meta.scope_value}</div>
            </div>
        `;
    }

    if (templateKey !== 'no_assessment') {
        const sections = config.sections || {};
        html += '<div class="summary-sections">';
        
        // Funkcja pomocnicza do budowania listy z linkami
        const renderLinkList = (items, showFailedTests = false) => {
            return `<ul class="summary-link-list">${items.map(item => `
                <li>
                    <div class="summary-item-content">
                        <a href="#${item.targetId}" 
                           class="summary-anchor"
                           onclick="event.preventDefault(); scrollToRequirement('${item.targetId}');">
                            ${item.label}
                        </a>
                        ${item.comment ? `<p class="summary-item-comment">Komentarz: ${item.comment}</p>` : ''}
                        ${showFailedTests && item.failedTests && item.failedTests.length > 0 ? `
                        ${(() => {
                            const failed = item.failedTests.filter(t => t.status === 'fail');
                            const passed = item.failedTests.filter(t => t.status === 'pass' && t.comment);
                            const na = item.failedTests.filter(t => t.status === 'na');
                            
                            let html = '';
                            if (failed.length > 0) {
                                html += `<p class="summary-failed-tests-label">Niespełnione testy jednostkowe:</p>
                                <ul class="summary-failed-tests">
                                    ${failed.map(t => `<li><strong>${t.title}</strong>${t.comment ? ` — ${t.comment}` : ''}</li>`).join('')}
                                </ul>`;
                            }
                            if (passed.length > 0) {
                                html += `<p class="summary-failed-tests-label">Spełnione testy jednostkowe (z komentarzem):</p>
                                <ul class="summary-failed-tests">
                                    ${passed.map(t => `<li><strong>${t.title}</strong>${t.comment ? ` — ${t.comment}` : ''}</li>`).join('')}
                                </ul>`;
                            }
                            if (na.length > 0) {
                                html += `<p class="summary-failed-tests-label">Wykluczone testy jednostkowe (z opisem przyczyny):</p>
                                <ul class="summary-failed-tests">
                                    ${na.map(t => `<li><strong>${t.title}</strong>${t.comment ? ` — ${t.comment}` : ''}</li>`).join('')}
                                </ul>`;
                            }
                            return html;
                        })()}` : ''}
                    </div>
                </li>`).join('')}</ul>`;
        };

        // Podział na dwie kategorie artykułów
        const filterByCat = (list, cat) => list.filter(item => item.category === cat);

        const renderCategorySection = (catTitle, catItems) => {
            const { failures: cF, passed: cP, inapplicable: cN, untested: cU } = catItems;
            if (cF.length + cP.length + cN.length + cU.length === 0) return '';
            let catHtml = `<h3 class="summary-category-header">${catTitle}</h3>`;
            if (cF.length > 0) {
                catHtml += `<h4>${sections.failures_label || 'Wykryte niezgodności:'}</h4>${renderLinkList(cF, true)}`;
            }
            if (cP.length > 0) {
                catHtml += `<h4>${sections.passed_label || 'Kryteria ocenione jako spełnione:'}</h4>${renderLinkList(cP, true)}`;
            }
            if (cN.length > 0) {
                catHtml += `<h4>${sections.inapplicable_label || 'Kryteria niemające zastosowania:'}</h4>${renderLinkList(cN, true)}`;
            }
            if (cU.length > 0) {
                catHtml += `<h4>${sections.untested_label || 'Kryteria niepoddane ocenie:'}</h4>${renderLinkList(cU, true)}`;
            }
            return catHtml;
        };

        html += renderCategorySection('Wymagania dostępności (Art. 7–22)', {
            failures: filterByCat(failures, 'accessibility_requirements'),
            passed: filterByCat(passed, 'accessibility_requirements'),
            inapplicable: filterByCat(inapplicable, 'accessibility_requirements'),
            untested: filterByCat(untested, 'accessibility_requirements')
        });
        html += renderCategorySection('Obowiązki informacyjne (Art. 23, 24, 26, 32, 33)', {
            failures: filterByCat(failures, 'service_provider_obligations'),
            passed: filterByCat(passed, 'service_provider_obligations'),
            inapplicable: filterByCat(inapplicable, 'service_provider_obligations'),
            untested: filterByCat(untested, 'service_provider_obligations')
        });

        // Uwaga / Wnioski
        if (sections.note_label) {
            html += `<p style="margin-top:1rem;"><strong>${sections.note_label}</strong> ${sections.note_value}</p>`;
        }

        if (sections.conclusions_label) {
            html += `<h3>${sections.conclusions_label}</h3><p>${sections.conclusions_value}</p>`;
        }

        // Podstawa prawna na końcu podsumowania
        if (summaryTemplates && summaryTemplates.legal_basis) {
            html += `
                <p class="summary-legal-basis" style="margin-top: 2rem; padding-top: 1rem; border-top: 1px solid var(--muted-border-color); text-align: center;">
                    ${summaryTemplates.legal_basis}
                </p>
            `;
        }

        html += '</div>';
    }

    if (templateKey !== 'no_assessment') {
        html += `
            <footer style="margin-top: 2rem; display: flex; flex-wrap: wrap; gap: 1rem;">
                <button class="outline" onclick="downloadWizardSpreadsheet(true)">
                    <i data-lucide="file-spreadsheet" aria-hidden="true"></i> Pobierz podsumowanie w formacie Excel
                </button>
                <button class="outline" onclick="downloadSummaryODT()">
                    <i data-lucide="file-text" aria-hidden="true"></i> Pobierz podsumowanie w formacie ODT
                </button>
                <button class="outline" onclick="downloadWizardAssessment()">
                    <i data-lucide="save" aria-hidden="true"></i> Zapisz stan oceny w formacie JSON
                </button>
            </footer>
        `;
    }

    html += `</article>`;

    displayArea.innerHTML = html;
    displayArea.scrollIntoView({ behavior: 'smooth', block: 'start' });
    
    // Ogłoś dla czytników ekranu
    const announcement = document.getElementById('generation-announcement');
    if (announcement) {
        announcement.textContent = `Wygenerowano podsumowanie oceny. Status: ${displayStatus}`;
        // Wyczyść ogłoszenie po chwili, by można było wyzwolić je ponownie
        setTimeout(() => { if (announcement.textContent.includes('podsumowanie')) announcement.textContent = ""; }, 1000);
    }

    if (typeof lucide !== 'undefined') lucide.createIcons();
}

/**
 * Pomocnicza funkcja do usuwania polskich znaków i znaków specjalnych z nazw plików
 */
function slugifyWizard(text) {
    if (!text) return '';
    const mapping = {
        'ą': 'a', 'ć': 'c', 'ę': 'e', 'ł': 'l', 'ń': 'n', 'ó': 'o', 'ś': 's', 'ź': 'z', 'ż': 'z',
        'Ą': 'A', 'Ć': 'C', 'Ę': 'E', 'Ł': 'L', 'Ń': 'N', 'Ó': 'O', 'Ś': 'S', 'Ź': 'Z', 'Ż': 'Z'
    };
    let slug = text.toString().split('').map(char => mapping[char] || char).join('')
        .replace(/[^a-z0-9]/gi, '_')
        .replace(/_+/g, '_')
        .replace(/^_+|_+$/g, '')
        .toLowerCase();
    
    // Ogranicz długość slugu do 60 znaków dla kompatybilności z systemami plików
    if (slug.length > 60) {
        slug = slug.substring(0, 60);
    }
    
    return slug;
}

/**
 * Generuje ustandaryzowaną nazwę pliku
 */
function generateWizardFileName(extension) {
    const resultsArea = document.getElementById('resultsArea');
    const profileName = resultsArea?.getAttribute('data-product-name') || 'arkusz';
    const productName = document.getElementById('wizard-product-name')?.value || '';
    const date = new Date().toISOString().split('T')[0];

    const pProfile = slugifyWizard(profileName);
    // Obciąć długą nazwę produktu (max 50 znaków przed slugify) aby uniknąć zbyt długiej nazwy pliku
    let truncatedProductName = productName;
    if (truncatedProductName && truncatedProductName.length > 50) {
        // Spróbuj obciąć na pierwszej przecinku lub nawiasie, jeśli jest
        const commaIdx = truncatedProductName.indexOf(',');
        const parenIdx = truncatedProductName.indexOf('(');
        const cutIdx = commaIdx > 0 && commaIdx < 50 ? commaIdx : (parenIdx > 0 && parenIdx < 50 ? parenIdx : 50);
        truncatedProductName = truncatedProductName.substring(0, cutIdx).trim();
    }
    const pProduct = (truncatedProductName && truncatedProductName !== 'Produkt/Usługa' && truncatedProductName !== 'Produkt') ? slugifyWizard(truncatedProductName) : '';
    
    // Pliki JSON to wersje robocze (arkusz), Excel/ODT to raporty (podsumowanie)
    const prefix = (extension === 'json') ? 'arkusz' : 'podsumowanie';
    let base = `${prefix}_${pProfile}`;
    if (pProduct) base += `_${pProduct}`;
    
    return `${base}_${date}.${extension}`;
}

// Pomocnik do normalizacji ID
function normalizeId(rawId) {
    if (!rawId) return '';
    rawId = rawId.trim();
    if (rawId.startsWith('C.')) return rawId;
    // Mapuj "9.1.1.1" -> "C.9.1.1.1"
    if (/^\d/.test(rawId)) return 'C.' + rawId;
    return rawId;
}

/**
 * Generuje dokument ODT z podsumowaniem (używa JSZip)
 */
async function downloadSummaryODT() {
    if (typeof exportToODT !== 'function') {
        showToast('Funkcja eksportu do ODT nie jest dostępna. Sprawdź, czy załadowano exporter.js.', 'error');
        return;
    }

    const inputProductName = document.getElementById('wizard-product-name')?.value;
    const productName = (inputProductName && inputProductName !== 'Produkt' && inputProductName !== 'Produkt/Usługa') 
        ? inputProductName 
        : 'Nieokreślony';
    const productDesc = document.getElementById('wizard-product-desc')?.value || '';
    const auditor = document.getElementById('wizard-auditor-name')?.value || '';
    
    // Pobierz dane z DOM (aby odzwierciedlić aktualny stan zaznaczeń w Wizardzie)
    const rows = Array.from(document.querySelectorAll('.requirement-row'));
    
    // Obsługa przełącznika Art. 19
    const art19Switch = document.querySelector('input[role="switch"]');
    const isArt19Enabled = art19Switch ? art19Switch.checked : false;
    
    // Filtrowanie (tylko widoczne/aktywne wiersze)
    const activeRows = rows.filter(row => {
        const isInArt19Container = row.closest('[data-art19-container="true"]');
        if (isInArt19Container) return isArt19Enabled;
        return true;
    });

    const tests = [];
    const results = {};
    let passedCount = 0;
    let failedCount = 0;

    activeRows.forEach((row, index) => {
        let rawArticle = row.querySelector('.requirement-id span[aria-hidden="true"]')?.textContent?.trim() || '';
        const title = row.querySelector('.requirement-text')?.textContent?.trim() || '';
        const note = row.querySelector('textarea')?.value || '';
        
        // Upewnij się, że format ID pasuje do oczekiwań getAuditStats/exportToODT
        const id = normalizeId(rawArticle);

        // Dodajemy definicję testu
        tests.push({
            id: id,
            title: title,
            type: 'test'
        });

        // Sprawdzamy stan radio
        const selectedRadio = row.querySelector('input[type="radio"]:checked');
        let status = 'nt'; // domyślnie nietestowany
        if (selectedRadio) {
            const val = selectedRadio.value;
            // Mapuj wartości radio Wizarda na kody statusów wewnętrznych
            if (val === 'compliant') status = 'pass';
            else if (val === 'non-compliant') status = 'fail';
            else if (val === 'not-applicable') status = 'na';
        }

        results[id] = {
            status: status,
            note: note
        };
        
        if (status === 'pass') passedCount++;
        if (status === 'fail') failedCount++;
    });

    // Użyj logiki nazywania pliku z wizarda
    const targetFilename = generateWizardFileName('odt');

    // Konstruujemy obiekt stanu kompatybilny z summary.js/exporter.js
    // Custom Reports: Budujemy "customSections" aby ODT wyglądał identycznie jak Excel (Podsumowanie opisowe)

    const summaryData = getAssessmentSummaryData();
    const stats = window.utils.getAuditStats({ results: results, tests: tests });
    const templateKey = summaryData.templateKey || 'no_assessment';
    
    // Status Display String
    let displayStatus = 'BRAK DANYCH';
    if (templateKey !== 'no_assessment') {
        const config = summaryTemplates.compliance_summaries[templateKey];
        displayStatus = config.status;
        if (summaryData.untestedCount > 0) displayStatus += ' (ocena częściowa)';
        else displayStatus += ' (ocena pełna)';
    }

    // Metadane
    const resultsArea = document.getElementById('resultsArea');
    const selectedProductProfile = resultsArea?.getAttribute('data-product-name') || '';

    const customSections = [];

    // 1. Tytuł
    customSections.push({ type: 'title', level: 1, text: 'PODSUMOWANIE OCENY ZGODNOŚCI Z PAD' });
    customSections.push({ type: 'title', level: 2, text: `STATUS: ${displayStatus.toUpperCase()}` });

    // 2. Metadane (Key-Value)
    customSections.push({ type: 'KV', key: 'Data oceny:', value: new Date().toLocaleDateString('pl-PL') });
    customSections.push({ type: 'KV', key: 'Profil/Kategoria:', value: selectedProductProfile || '(nie podano)' });
    
    // Obsługa wyświetlania nazwy produktu (jeśli "Nieokreślony" to traktujemy jako brak)
    const displayProductName = (productName && productName !== 'Nieokreślony') ? productName : '(nie podano)';
    customSections.push({ type: 'KV', key: 'Przedmiot oceny:', value: displayProductName });
    
    customSections.push({ type: 'KV', key: 'Opis:', value: productDesc || '(nie podano)' });
    customSections.push({ type: 'KV', key: 'Osoba dokonująca oceny:', value: auditor || '(nie podano)' });
    customSections.push({ type: 'separator' });

    // Uwaga o brakujących ocenach
    if (summaryData.incompleteAssessments.length > 0) {
        customSections.push({ type: 'title', level: 3, text: '⚠️ Uwaga: Brakująca ocena klauzuli' });
        customSections.push({ type: 'list', items: summaryData.incompleteAssessments.map(item => ({ label: item.label })) });
    }

    // 3. Tekst główny (z szablonu)
    let descText = 'Raport wygenerowany z Konfiguratora.';
    if (templateKey !== 'no_assessment') {
         const config = summaryTemplates.compliance_summaries[templateKey];
         const fullProductName = getFullProductNameWizard();
         descText = config.description.replace('{productName}', fullProductName).replace(/<[^>]*>/g, '');
    }
    customSections.push({ type: 'text', text: descText });
    customSections.push({ type: 'separator' });

    // 4. Listy (Niezgodności / Zgodności itp.)
    if (templateKey !== 'no_assessment') {
         const config = summaryTemplates.compliance_summaries[templateKey];
         const sections = config.sections || {};
         
         // Podział na dwie kategorie artykułów
         const toItems = list => list.map(f => ({ label: f.label, note: f.comment, tests: f.failedTests }));
         // Dla spełnionych kryteriów - tylko testy z komentarzem
         const toItemsWithCommentedTests = list => list.map(f => ({ 
             label: f.label, 
             note: f.comment, 
             tests: f.failedTests.filter(t => t.comment) 
         }));
         const fc = cat => summaryData.failures.filter(f => f.category === cat);
         const pc = cat => summaryData.passed.filter(f => f.category === cat);
         const nc = cat => summaryData.inapplicable.filter(f => f.category === cat);
         const uc = cat => summaryData.untested.filter(f => f.category === cat);

         const pushCategorySection = (catTitle, cF, cP, cN, cU) => {
             if (cF.length + cP.length + cN.length + cU.length === 0) return;
             customSections.push({ type: 'title', level: 2, text: catTitle });
             if (cF.length > 0) {
                 customSections.push({ type: 'title', level: 3, text: sections.failures_label || 'Wykryte niezgodności:' });
                 customSections.push({ type: 'list', items: toItems(cF) });
             }
             if (cP.length > 0) {
                 customSections.push({ type: 'title', level: 3, text: sections.passed_label || 'Kryteria ocenione jako spełnione:' });
                 customSections.push({ type: 'list', items: toItemsWithCommentedTests(cP) });
             }
             if (cN.length > 0) {
                 customSections.push({ type: 'title', level: 3, text: sections.inapplicable_label || 'Kryteria niemające zastosowania:' });
                 customSections.push({ type: 'list', items: toItems(cN) });
             }
             if (cU.length > 0) {
                 customSections.push({ type: 'title', level: 3, text: sections.untested_label || 'Kryteria niepoddane ocenie:' });
                 customSections.push({ type: 'list', items: toItems(cU) });
             }
         };

         pushCategorySection(
             'Wymagania dostępności',
             fc('accessibility_requirements'), pc('accessibility_requirements'),
             nc('accessibility_requirements'), uc('accessibility_requirements')
         );
         pushCategorySection(
             'Obowiązki producenta/usługodawcy',
             fc('service_provider_obligations'), pc('service_provider_obligations'),
             nc('service_provider_obligations'), uc('service_provider_obligations')
         );

         // Konkluzje (np. walidator)
         if (sections.conclusions_label) {
             customSections.push({ type: 'title', level: 3, text: sections.conclusions_label });
             customSections.push({ type: 'text', text: sections.conclusions_value });
         }
         
         // Notatka prawna
         if (sections.note_label) {
             customSections.push({ type: 'separator' });
             customSections.push({ type: 'text', text: `${sections.note_label} ${sections.note_value}` });
         }
    }

    // Stopka: Podstawa prawna (Zawsze dodawana dla wszystkich raportów poza no_assessment)
    if (templateKey !== 'no_assessment' && summaryTemplates && summaryTemplates.legal_basis) {
        customSections.push({ type: 'separator' });
        customSections.push({ type: 'text', text: summaryTemplates.legal_basis });
    }

    const state = {
        product: getFullProductNameWizard(),
        productDesc: productDesc,
        auditor: auditor,
        // Ustawiamy flagę, żeby exporter wiedział że ma renderować custom sections zamiast domyślnego układu
        customSections: customSections,
        tests: tests,
        results: results
    };

    console.log('Generowanie raportu ODT (Wizard), stan:', state);
    console.log('Docelowa nazwa pliku:', targetFilename);
    
    try {
        // Nazwa pliku przekazana jako 3. argument do exporter.js (filenameOverride)
        exportToODT(state, null, targetFilename);
    } catch (e) {
        console.error('Błąd generowania ODT:', e);
        showToast('Wystąpił błąd podczas generowania raportu ODT: ' + e.message, 'error');
    }
}

/**
 * Konfiguruje funkcję zapisu w Wizardzie.
 */
let isDownloadingWizard = false;

/**
 * Generuje arkusz Excel z wymaganiami do wypełnienia (ExcelJS)
 */
async function downloadWizardSpreadsheet(includeSummary = false) {
    // Sprawdź, czy są dane do zapisania. Pobierz aktualne rzędy wymagań
    const requirementRows = document.querySelectorAll('.requirement-row');
    if (requirementRows.length === 0) {
        console.warn('Brak wymagań do eksportu do Excel.');
        showToast('Nie można wyeksportować: brak wygenerowanego arkusza oceny.', 'warning');
        
        // Komunikat dla screen readerów
        let liveRegion = document.getElementById('status-message');
        if (liveRegion) {
            liveRegion.innerText = 'Nie można wyeksportować: brak wygenerowanego arkusza oceny.';
        }
        
        return;
    }

    // Sprawdzenie czy ExcelJS jest dostępny
    if (typeof ExcelJS === 'undefined') {
        console.error('ExcelJS library is not loaded');
        let liveRegion = document.getElementById('status-message') || document.getElementById('a11y-live-region');
        if (!liveRegion) {
            liveRegion = document.createElement('div');
            liveRegion.id = 'status-message';
            liveRegion.className = 'sr-only';
            liveRegion.setAttribute('aria-live', 'polite');
            liveRegion.setAttribute('role', 'status');
            document.body.appendChild(liveRegion);
        }
        liveRegion.innerText = 'Błąd: Biblioteka ExcelJS nie została załadowana. Spróbuj odświeżyć stronę.';
        return;
    }

    const resultsArea = document.getElementById('resultsArea');
    const productName = document.getElementById('wizard-product-name')?.value || '';
    const productDesc = document.getElementById('wizard-product-desc')?.value || '';
    const auditor = document.getElementById('wizard-auditor-name')?.value || '';
    const selectedProductProfile = resultsArea.getAttribute('data-product-name') || '';
    const currentDate = new Date().toISOString().split('T')[0];

    // Utwórz workbook
    const workbook = new ExcelJS.Workbook();
    
    // Ustaw metadane dokumentu (Dostępność)
    const fullProductName = getFullProductNameWizard();
    const meshTitle = (fullProductName && fullProductName !== 'Profil nieokreślony') 
        ? `Raport z oceny zgodności ${fullProductName} - podsumowanie`
        : `Raport z oceny zgodności - podsumowanie`;

    workbook.creator = auditor || 'Narzędzie OZ-PAD';
    workbook.lastModifiedBy = auditor || 'Narzędzie OZ-PAD';
    workbook.created = new Date();
    workbook.modified = new Date();
    workbook.properties.date1904 = true;
    workbook.title = meshTitle;
    workbook.subject = 'Podsumowanie oceny zgodności z Polskim Aktem Dostępności';
    workbook.description = 'Dokument wygenerowany automatycznie przez Narzędzie OZ-PAD';

    // 4. Pobierz dane za pomocą nowej funkcji pomocniczej
    const summaryData = getAssessmentSummaryData();
    const rows = Array.from(document.querySelectorAll('.requirement-row')); // musimy przemapować wszystkie rzędy dla zapisu
    
    // --- ARKUSZ: PODSUMOWANIE (jeśli wybrano - teraz PIERWSZY) ---
    if (includeSummary && summaryData.templateKey !== 'no_assessment') {
        const summarySheet = workbook.addWorksheet('Podsumowanie opisowe');
        summarySheet.columns = [{ width: 120 }];
        
        const config = summaryTemplates.compliance_summaries[summaryData.templateKey];
        const displayDate = new Date().toLocaleDateString('pl-PL');
        
        let displayStatus = config.status;
        if (summaryData.untestedCount > 0) displayStatus += ' (ocena częściowa)';
        else displayStatus += ' (ocena pełna)';

        const addSummaryTitle = (text, size = 14) => {
            const r = summarySheet.addRow([text]);
            r.getCell(1).font = { bold: true, size: size };
            summarySheet.addRow([]); // Pusta linia po nagłówku
        };

        const addSummaryText = (label, value) => {
            const rowValue = value ? `${label} ${value}` : label;
            const r = summarySheet.addRow([rowValue]);
            r.getCell(1).alignment = { wrapText: true };
            
            // Pogrub wartości gdy obecna jest etykieta (etykieta — normalny, wartość — pogrubiona)
            if (label && value) {
                // ExcelJS Rich Text (sformatowany tekst)
                r.getCell(1).value = {
                    richText: [
                        { text: label + ' ' },
                        { font: { bold: true }, text: value }
                    ]
                };
            }
        };

        addSummaryTitle('PODSUMOWANIE OCENY ZGODNOŚCI Z PAD', 16);
        summarySheet.addRow([]); // Odstęp przed statusem
        addSummaryTitle(`STATUS: ${displayStatus.toUpperCase()}`, 14);
        summarySheet.addRow([]); // Odstęp po statusie
        
        // Zmieniona kolejność metadanych
        addSummaryText('Data oceny:', displayDate);
        addSummaryText('Profil/Kategoria:', selectedProductProfile || '(nie podano)');
        
        const displayProductName = (productName && productName !== 'Nieokreślony') ? productName : '(nie podano)';
        addSummaryText('Przedmiot oceny:', displayProductName);
        
        addSummaryText('Opis:', productDesc || '(nie podano)');
        addSummaryText('Osoba oceniająca:', auditor || '(nie podano)');
        
        summarySheet.addRow([]); // Separator po metadanych
        
        // Uwaga o brakujących ocenach
        if (summaryData.incompleteAssessments.length > 0) {
            const warningTitle = summarySheet.addRow(['⚠️ Uwaga: Brakująca ocena klauzuli']);
            warningTitle.getCell(1).font = { bold: true, size: 11, color: { argb: 'FFFF6600' } }; // Pomarańczowy
            
            summaryData.incompleteAssessments.forEach(item => {
                const r = summarySheet.addRow([`• ${item.label}`]);
                r.getCell(1).alignment = { wrapText: true };
            });
            summarySheet.addRow([]); // Separator po ostrzeżeniu
        }
        
        const fullProductName = getFullProductNameWizard();
        const descText = config.description.replace('{productName}', fullProductName).replace(/<[^>]*>/g, '');
        // Dodaj description jako zwykły tekst
        const descRow = summarySheet.addRow([descText]);
        descRow.getCell(1).alignment = { wrapText: true };
        summarySheet.addRow([]); // Separator

        // Helper do dodawania listy z komentarzami i testami
        const addListItems = (items) => {
             items.forEach(item => {
                const r = summarySheet.addRow([`• ${item.label}`]);
                r.getCell(1).alignment = { wrapText: true };
                if (item.comment) {
                    // Komentarz w nowej linii, wcięty
                    const rc = summarySheet.addRow([`Komentarz: ${item.comment}`]);
                    // Standardowy kolor, bez kursywy, wcięcie
                    rc.getCell(1).font = { size: 10 }; 
                    rc.getCell(1).alignment = { wrapText: true, indent: 2 }; 
                }
                // Testy jednostkowe - podzielone na grupy wg statusu
                if (item.failedTests && item.failedTests.length > 0) {
                    const failed = item.failedTests.filter(t => t.status === 'fail');
                    const passed = item.failedTests.filter(t => t.status === 'pass' && t.comment);
                    const na = item.failedTests.filter(t => t.status === 'na');
                    
                    // Niespełnione
                    if (failed.length > 0) {
                        const rt = summarySheet.addRow(['Niespełnione testy jednostkowe:']);
                        rt.getCell(1).font = { size: 10, bold: true };
                        rt.getCell(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF5F5F5' } };
                        rt.getCell(1).alignment = { wrapText: true, indent: 1 };
                        
                        failed.forEach(test => {
                            let testLabel = `  ↳ ${test.title}`;
                            if (test.comment) testLabel += ` — ${test.comment}`;
                            const rtt = summarySheet.addRow([testLabel]);
                            rtt.getCell(1).font = { size: 9 };
                            rtt.getCell(1).alignment = { wrapText: true };
                            rtt.getCell(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF5F5F5' } };
                        });
                    }
                    
                    // Spełnione z komentarzem
                    if (passed.length > 0) {
                        const rt = summarySheet.addRow(['Spełnione testy jednostkowe (z komentarzem):']);
                        rt.getCell(1).font = { size: 10, bold: true };
                        rt.getCell(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF5F5F5' } };
                        rt.getCell(1).alignment = { wrapText: true, indent: 1 };
                        
                        passed.forEach(test => {
                            let testLabel = `  ↳ ${test.title}`;
                            if (test.comment) testLabel += ` — ${test.comment}`;
                            const rtt = summarySheet.addRow([testLabel]);
                            rtt.getCell(1).font = { size: 9 };
                            rtt.getCell(1).alignment = { wrapText: true };
                            rtt.getCell(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF5F5F5' } };
                        });
                    }
                    
                    // Nie dotyczy z komentarzem
                    if (na.length > 0) {
                        const rt = summarySheet.addRow(['Wykluczone testy jednostkowe (z opisem przyczyny):']);
                        rt.getCell(1).font = { size: 10, bold: true };
                        rt.getCell(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF5F5F5' } };
                        rt.getCell(1).alignment = { wrapText: true, indent: 1 };
                        
                        na.forEach(test => {
                            let testLabel = `  ↳ ${test.title}`;
                            if (test.comment) testLabel += ` — ${test.comment}`;
                            const rtt = summarySheet.addRow([testLabel]);
                            rtt.getCell(1).font = { size: 9 };
                            rtt.getCell(1).alignment = { wrapText: true };
                            rtt.getCell(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF5F5F5' } };
                        });
                    }
                }
            });
            summarySheet.addRow([]); // Odstęp po sekcji
        };

        const sections = config.sections || {};

        // Podział na dwie kategorie artykułów
        const filterByCat = (list, cat) => list.filter(item => item.category === cat);

        const addCategorySection = (catTitle, cF, cP, cN, cU) => {
            if (cF.length + cP.length + cN.length + cU.length === 0) return;
            
            addSummaryTitle(catTitle, 12);
            
            if (cF.length > 0) {
                addSummaryTitle(sections.failures_label || 'Wykryte niezgodności:', 11);
                addListItems(cF);
            }
            if (cP.length > 0) {
                addSummaryTitle(sections.passed_label || 'Kryteria ocenione jako spełnione:', 11);
                addListItems(cP);
            }
            if (cN.length > 0) {
                addSummaryTitle(sections.inapplicable_label || 'Kryteria niemające zastosowania:', 11);
                addListItems(cN);
            }
            if (cU.length > 0) {
                addSummaryTitle(sections.untested_label || 'Kryteria niepoddane ocenie:', 11);
                addListItems(cU);
            }
        };

        // Wymagania dostępności
        addCategorySection(
            'Wymagania dostępności',
            filterByCat(summaryData.failures, 'accessibility_requirements'),
            filterByCat(summaryData.passed, 'accessibility_requirements'),
            filterByCat(summaryData.inapplicable, 'accessibility_requirements'),
            filterByCat(summaryData.untested, 'accessibility_requirements')
        );

        // Obowiązki producenta/usługodawcy
        addCategorySection(
            'Obowiązki producenta/usługodawcy',
            filterByCat(summaryData.failures, 'service_provider_obligations'),
            filterByCat(summaryData.passed, 'service_provider_obligations'),
            filterByCat(summaryData.inapplicable, 'service_provider_obligations'),
            filterByCat(summaryData.untested, 'service_provider_obligations')
        );

        // Wnioski
        if (sections.conclusions_label) {
            addSummaryTitle(sections.conclusions_label, 12);
            const r = summarySheet.addRow([sections.conclusions_value]);
            r.getCell(1).alignment = { wrapText: true };
            summarySheet.addRow([]);
        }
        
        // Notatka prawna
        if (sections.note_label) {
             summarySheet.addRow([]);
             addSummaryText(sections.note_label, sections.note_value);
        }

        // Stopka: Podstawa prawna
        if (summaryTemplates && summaryTemplates.legal_basis) {
            summarySheet.addRow([]);
            summarySheet.addRow([]);
            const footerRow = summarySheet.addRow([summaryTemplates.legal_basis]);
            // Formatowanie spójne z ODT (standardowy font)
            footerRow.getCell(1).font = { size: 10 };
            footerRow.getCell(1).alignment = { wrapText: true, horizontal: 'center' };
        }
    }

    // --- ARKUSZ: OCENA SZCZEGÓŁOWA (teraz DRUGI, lub pierwszy jeśli brak summary) ---
    const worksheet = workbook.addWorksheet('Ocena szczegółowa');

    // Konfiguracja kolumn
    worksheet.columns = [
        { key: 'article', width: 22 },
        { key: 'requirement', width: 75 },
        { key: 'status', width: 25 },
        { key: 'comment', width: 55 }
    ];

    // 1. Nagłówek główny
    const titleCell = worksheet.getCell('A1');
    titleCell.value = 'ARKUSZ OCENY ZGODNOŚCI Z PAD';
    worksheet.mergeCells('A1:D1');
    titleCell.font = { bold: true, size: 16 };
    titleCell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: false };
    worksheet.getRow(1).height = 35;

    worksheet.addRow([]); // Pusty wiersz (wiersz 2)

    // 2. Metadane
    const metaData = [
        ['Profil oceny:', selectedProductProfile],
        ['Nazwa produktu/usługi:', productName || '(nie podano)'],
        ['Opis/Wersja/URL:', productDesc || '(nie podano)'],
        ['Osoba dokonująca oceny:', auditor || '(nie podano)'],
        ['Data wypełnienia:', currentDate]
    ];

    metaData.forEach((data, index) => {
        const row = worksheet.addRow(data);
        row.getCell(1).font = { bold: true };
        row.getCell(1).alignment = { horizontal: 'left', vertical: 'middle', wrapText: true };
        row.getCell(2).alignment = { horizontal: 'left', vertical: 'middle', wrapText: true };
    });

    worksheet.addRow([]); // Pusty wiersz

    // 3. Nagłówek tabeli (Kolumny)
    const headerRow = worksheet.addRow(['Artykuł', 'Wymaganie', 'Ocena spełnienia', 'Komentarz']);
    headerRow.eachCell((cell) => {
        cell.font = { bold: true, color: { argb: 'FFFFFFFF' } };
        cell.fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'FF4472C4' }
        };
        cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
        cell.border = {
            top: { style: 'thin' },
            left: { style: 'thin' },
            bottom: { style: 'thin' },
            right: { style: 'thin' }
        };
    });
    headerRow.height = 30;

    const standardRowsData = [];
    const art19RowsData = [];
    const art19Description = "Jeżeli produkt albo usługa posiadają funkcje lub właściwości, które nie są objęte wymaganiami dostępności określonymi w art. 7–18, podmiot gospodarczy stosuje do nich odpowiednie kryteria funkcjonalne. Kryteria funkcjonalne mogą być stosowane zamiast jednego wymagania dostępności albo większej liczby wymagań dostępności określonych w art. 7–18, o ile zastosowanie tych kryteriów funkcjonalnych prowadzi do równoważnej albo większej dostępności produktu albo usługi dla osób ze szczególnymi potrzebami.";

    // Pobierz wszystkie wiersze (nie tylko aktywne), aby arkusz był kompletny, 
    // lub tylko aktywne jeśli tak wynika z kontekstu. 
    // Zwykle Excel powinien zawierać to co widzi użytkownik.
    rows.forEach((rowEl) => {
        const isInArt19Container = rowEl.closest('[data-art19-container="true"]');
        if (isInArt19Container && !summaryData.isArt19Enabled) return;

        const article = rowEl.querySelector('.requirement-id span[aria-hidden="true"]')?.textContent?.trim() || '';
        const requirementText = rowEl.querySelector('.requirement-text')?.textContent?.trim() || '';

        // Użyj właściwych nazw pól (nie querySelector('input[type=radio]:checked'), bo też łapie testy jednostkowe)
        const safeArticleId = article.replace(/[^a-z0-9]/gi, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
        const selectedStatusEl = rowEl.querySelector(`input[type="radio"][name="status-${safeArticleId}"]:checked`);
        let currentStatus = 'Wybierz...';
        if (selectedStatusEl) {
            const val = selectedStatusEl.value;
            if (val === 'compliant') currentStatus = 'Spełnione';
            else if (val === 'non-compliant') currentStatus = 'Niespełnione';
            else if (val === 'not-applicable') currentStatus = 'Nie dotyczy';
        }

        // Użyj właściwego selektora dla komentarza klauzuli (nie pierwszej textarea w DOM)
        const currentComment = rowEl.querySelector(`textarea[name="comment-${safeArticleId}"]`)?.value || '';

        // Zbierz testy jednostkowe z tej klauzuli
        const testCards = Array.from(rowEl.querySelectorAll('.checklist-test-item[data-test-id]'));
        const unitTests = testCards.map(card => {
            const testDataId = card.getAttribute('data-test-id');
            const safeTestId = testDataId.replace(/[^a-z0-9]/gi, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
            const testTitle = card.querySelector('.checklist-test-summary')?.textContent?.trim() || '';
            const testRadio = card.querySelector(`input[name="test-status-${safeTestId}"]:checked`);
            let testStatus = 'Wybierz...';
            if (testRadio) {
                if (testRadio.value === 'pass') testStatus = 'Spełnione';
                else if (testRadio.value === 'fail') testStatus = 'Niespełnione';
                else if (testRadio.value === 'na') testStatus = 'Nie dotyczy';
            }
            const testComment = card.querySelector(`textarea[name="test-comment-${safeTestId}"]`)?.value || '';
            return { testDataId, testTitle, testStatus, testComment };
        });

        const rowData = { article, requirementText, currentStatus, currentComment, unitTests };

        if (article.includes('Art. 19')) {
            art19RowsData.push(rowData);
        } else {
            standardRowsData.push(rowData);
        }
    });

    // Funkcja pomocnicza do dodawania i formatowania wierszy danych (z testami jednostkowymi)
    const addDataRows = (ws, dataArray) => {
        dataArray.forEach(rowData => {
            const { article, requirementText, currentStatus, currentComment, unitTests } = rowData;
            const newRow = ws.addRow([article, requirementText, currentStatus, currentComment]);

            newRow.getCell(1).alignment = { vertical: 'top', horizontal: 'left', wrapText: true };
            newRow.getCell(2).alignment = { vertical: 'top', horizontal: 'left', wrapText: true };
            newRow.getCell(3).alignment = { vertical: 'top', horizontal: 'center', wrapText: true };
            newRow.getCell(4).alignment = { vertical: 'top', horizontal: 'left', wrapText: true };

            newRow.eachCell((cell) => {
                cell.border = {
                    top: { style: 'thin' },
                    left: { style: 'thin' },
                    bottom: { style: 'thin' },
                    right: { style: 'thin' }
                };
            });

            newRow.getCell(3).dataValidation = {
                type: 'list',
                allowBlank: true,
                formulae: ['"Wybierz...,Spełnione,Niespełnione,Nie dotyczy"'],
                showErrorMessage: true,
                errorTitle: 'Nieprawidłowa wartość',
                error: 'Wybierz wartość z listy: Spełnione, Niespełnione lub Nie dotyczy'
            };

            // Testy jednostkowe – wiersze wcięte pod klauzulą
            if (unitTests && unitTests.length > 0) {
                unitTests.forEach(test => {
                    const testRow = ws.addRow(['', `  ↳ ${test.testTitle}`, test.testStatus, test.testComment]);
                    testRow.getCell(1).alignment = { vertical: 'top', horizontal: 'left' };
                    testRow.getCell(2).alignment = { vertical: 'top', horizontal: 'left', wrapText: true, indent: 2 };
                    testRow.getCell(3).alignment = { vertical: 'top', horizontal: 'center', wrapText: true };
                    testRow.getCell(4).alignment = { vertical: 'top', horizontal: 'left', wrapText: true };
                    testRow.getCell(2).font = { size: 9 };
                    testRow.getCell(3).font = { size: 9 };
                    testRow.getCell(4).font = { size: 9 };
                    testRow.eachCell((cell) => {
                        cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF5F5F5' } };
                        cell.border = {
                            top: { style: 'hair' },
                            left: { style: 'thin' },
                            bottom: { style: 'hair' },
                            right: { style: 'thin' }
                        };
                    });
                    // Dodaj walidację danych dla kolumny oceny testu
                    testRow.getCell(3).dataValidation = {
                        type: 'list',
                        allowBlank: true,
                        formulae: ['"Wybierz...,Spełnione,Niespełnione,Nie dotyczy"'],
                        showErrorMessage: true,
                        errorTitle: 'Nieprawidłowa wartość',
                        error: 'Wybierz wartość z listy: Spełnione, Niespełnione lub Nie dotyczy'
                    };
                });
            }
        });
    };

    // Dodaj wiersze standardowe
    addDataRows(worksheet, standardRowsData);

    // 5. Sekcja Art. 19
    if (art19RowsData.length > 0) {
        worksheet.addRow([]); // Odstęp

        
        // Opis Art. 19
        const descRow = worksheet.addRow([art19Description]);
        const currentRowNum = descRow.number;
        worksheet.mergeCells(`A${currentRowNum}:D${currentRowNum}`);
        descRow.getCell(1).alignment = { vertical: 'middle', horizontal: 'left', wrapText: true };
        descRow.getCell(1).font = { italic: true, color: { argb: 'FF555555' } };
        descRow.height = 60;

        // Nagłówek tabeli dla Art. 19
        const art19Header = worksheet.addRow(['Artykuł', 'Wymaganie', 'Ocena spełnienia', 'Komentarz']);
        art19Header.eachCell((cell) => {
            cell.font = { bold: true, color: { argb: 'FFFFFFFF' } };
            cell.fill = {
                type: 'pattern',
                pattern: 'solid',
                fgColor: { argb: 'FF777777' }
            };
            cell.alignment = { horizontal: 'center', vertical: 'middle' };
            cell.border = {
                top: { style: 'thin' },
                left: { style: 'thin' },
                bottom: { style: 'thin' },
                right: { style: 'thin' }
            };
        });
        art19Header.height = 25;

        // Dodaj wiersze Art. 19
        addDataRows(worksheet, art19RowsData);
    }

    // Zamrożenie nagłówka
    worksheet.views = [{ state: 'frozen', xSplit: 0, ySplit: 9 }];

    // --- ARKUSZ 2: PODSUMOWANIE (jeśli wybrano) ---
    // Kod ten został przeniesiony na początek funkcji, aby arkusz podsumowania był pierwszy.
    // Usunięto zduplikowany blok kodu.

    // Generowanie i pobieranie pliku
    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url = window.URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = generateWizardFileName('xlsx');
    document.body.appendChild(anchor);
    anchor.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(anchor);

    // Feedback
    let liveRegion = document.getElementById('status-message') || document.getElementById('a11y-live-region');
    if (liveRegion) {
        liveRegion.innerText = 'Pobrano arkusz oceny w formacie Excel' + (includeSummary ? ' z podsumowaniem.' : '.');
    }
}

/**
 * Zbiera dane z formularza wizard'a i pobiera je jako JSON w formacie EARL
 */
function downloadWizardAssessment() {
    // 1. Sprawdź, czy są dane do zapisania. Pobierz aktualne rzędy wymagań
    const rows = document.querySelectorAll('.requirement-row');
    if (rows.length === 0) {
        console.warn('Brak wymagań do zapisania.');
        showToast('Nie można zapisać: brak wygenerowanego arkusza oceny.', 'warning');
        
        // Komunikat dla screen readerów
        let liveRegion = document.getElementById('status-message');
        if (liveRegion) {
            liveRegion.innerText = 'Nie można zapisać: brak wygenerowanego arkusza oceny.';
        }
        
        return;
    }

    // Zbierz dane produktu
    const productName = document.getElementById('wizard-product-name')?.value || '';
    const productDesc = document.getElementById('wizard-product-desc')?.value || '';
    const auditor = document.getElementById('wizard-auditor-name')?.value || '';

    // EARL Context
    const context = {
        "earl": "http://www.w3.org/ns/earl#",
        "dct": "http://purl.org/dc/terms/",
        "foaf": "http://xmlns.com/foaf/0.1/",
        "sch": "http://schema.org/",
        "xsd": "http://www.w3.org/2001/XMLSchema#",
        "eaa": "https://github.com/ka-er-zet/eaa-pfron#"
    };

    // Assertor (Narzędzie)
    const toolAssertor = {
        "@id": "_:toolAssertor",
        "@type": ["earl:Software", "earl:Assertor"],
        "dct:title": "Konfigurator Arkusza EAA",
        "dct:description": "Narzędzie do tworzenia arkuszy oceny dostępności cyfrowej wg EN 301 549",
        "dct:hasVersion": "1.0.0"
    };

    // Human Assertor (jeśli podany)
    let mainAssertor = toolAssertor;
    const graph = [toolAssertor];

    if (auditor) {
        const humanAssertor = {
            "@id": "_:humanAssertor",
            "@type": ["foaf:Person", "earl:Assertor"],
            "foaf:name": auditor
        };

        mainAssertor = {
            "@id": "_:compoundAssertor",
            "@type": "earl:Assertor",
            "earl:mainAssertor": { "@id": "_:humanAssertor" },
            "dct:description": "Ocena przeprowadzona przez człowieka przy użyciu narzędzia"
        };

        graph.push(humanAssertor);
        graph.push(mainAssertor);
    }

    // Test Subject (Produkt)
    const art19Switch = document.querySelector('input[role="switch"]');
    const isArt19Enabled = art19Switch ? art19Switch.checked : false;
    const selectedProduct = resultsArea?.getAttribute('data-selected-product') || '';

    const testSubject = {
        "@id": "_:subject",
        "@type": ["earl:TestSubject", "sch:Product"],
        "dct:title": productName || "Nieznany produkt",
        "dct:description": productDesc || '',
        "dct:date": new Date().toISOString(),
        "eaa:art19Enabled": isArt19Enabled,
        "eaa:productCategory": selectedProduct
    };
    graph.push(testSubject);

    // Assertions z ocen wymagań
    document.querySelectorAll('.requirement-row').forEach((row) => {
        const articleEl = row.querySelector('.requirement-id span[aria-hidden="true"]');
        if (!articleEl) return;

        const article = articleEl.textContent;
        const requirementText = row.querySelector('.requirement-text')?.textContent || '';
        
        // Obliczyć safeArticleId tak samo jak w generateAssessmentRows()
        const safeArticleId = article.replace(/[^a-z0-9]/gi, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
        
        // Szukaj radio buttons dla tego wymagania
        const radios = row.querySelectorAll(`input[name="status-${safeArticleId}"]`);
        const textarea = row.querySelector(`textarea[name="comment-${safeArticleId}"]`);

        let status = null;
        let outcome = 'earl:untested';

        radios.forEach(radio => {
            if (radio.checked) {
                status = radio.value;
                if (status === 'compliant') outcome = 'earl:passed';
                else if (status === 'non-compliant') outcome = 'earl:failed';
                else if (status === 'not-applicable') outcome = 'earl:inapplicable';
            }
        });

        const assertion = {
            "@type": "earl:Assertion",
            "earl:assertedBy": { "@id": auditor ? "_:compoundAssertor" : "_:toolAssertor" },
            "earl:subject": { "@id": "_:subject" },
            "earl:test": {
                "@type": "earl:TestCriterion",
                "dct:title": requirementText,
                "dct:identifier": article
            },
            "earl:result": {
                "@type": "earl:TestResult",
                "earl:outcome": { "@id": outcome },
                "dct:description": textarea?.value || '',
                "dct:date": new Date().toISOString()
            },
            "earl:mode": { "@id": "earl:manual" }
        };

        graph.push(assertion);
    });

    // Assertions z testów (Jak sprawdzić?)
    document.querySelectorAll('.checklist-test-item[data-test-id]').forEach((card) => {
        const testDataId = card.dataset.testId;
        // Konwertuj "U.7.1.1.a--test--0" → "U.7.1.1.a#test-0" dla identyfikatora EARL
        const earlTestId = testDataId.replace(/--test--(\d+)$/, '#test-$1');
        const safeTestId = testDataId.replace(/[^a-z0-9]/gi, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');

        const radios = card.querySelectorAll(`input[name="test-status-${safeTestId}"]`);
        const textarea = card.querySelector(`textarea[name="test-comment-${safeTestId}"]`);

        let testOutcome = 'earl:untested';
        radios.forEach(radio => {
            if (radio.checked) {
                if (radio.value === 'pass') testOutcome = 'earl:passed';
                else if (radio.value === 'fail') testOutcome = 'earl:failed';
                else if (radio.value === 'na') testOutcome = 'earl:inapplicable';
            }
        });

        const testAssertion = {
            "@type": "earl:Assertion",
            "earl:assertedBy": { "@id": auditor ? "_:compoundAssertor" : "_:toolAssertor" },
            "earl:subject": { "@id": "_:subject" },
            "earl:test": {
                "@type": "earl:TestCriterion",
                "dct:identifier": earlTestId
            },
            "earl:result": {
                "@type": "earl:TestResult",
                "earl:outcome": { "@id": testOutcome },
                "dct:description": textarea?.value || '',
                "dct:date": new Date().toISOString()
            },
            "earl:mode": { "@id": "earl:manual" }
        };

        graph.push(testAssertion);
    });

    // Wygeneruj EARL JSON-LD
    const earlReport = {
        "@context": context,
        "@graph": graph
    };

    // Pobierz jako JSON
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(earlReport, null, 2));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", generateWizardFileName('json'));

    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();

    // Feedback
    let liveRegion = document.getElementById('status-message') || document.getElementById('a11y-live-region');
    if (!liveRegion) {
        liveRegion = document.createElement('div');
        liveRegion.id = 'status-message';
        liveRegion.className = 'sr-only';
        liveRegion.setAttribute('aria-live', 'polite');
        liveRegion.setAttribute('role', 'status');
        document.body.appendChild(liveRegion);
    }
    liveRegion.innerText = 'Zapisano wersję roboczą oceny w pliku JSON.';
}

/**
 * Obsługuje wczytywanie pliku JSON ze stanem oceny
 */
async function handleWizardFileLoad(event) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (e) => {
        try {
            const data = JSON.parse(e.target.result);

            // Pokaż sekcję setup, ukryj browser
            const setupSection = document.getElementById('setup-section');
            const browserSection = document.getElementById('browser-section');
            if (setupSection) setupSection.classList.remove('hidden');
            if (browserSection) browserSection.classList.add('hidden');

            // Sprawdzamy czy to format EARL (generowany przez Konfigurator)
            const graph = data['@graph'] || [];
            
            // 1. Znajdź TestSubject aby pobrać kategorię produktu i podstawowe info
            const subject = graph.find(it => it['@type'] && it['@type'].includes('earl:TestSubject'));
            const productCategory = subject?.['eaa:productCategory'] || '';
            const productName = subject?.['dct:title'] || '';
            const productDesc = subject?.['dct:description'] || '';
            const isArt19Enabled = subject?.['eaa:art19Enabled'] || false;

            // 2. Znajdź Assertor aby pobrać nazwisko osoby
            const humanAssertor = graph.find(it => it['@type'] && it['@type'].includes('foaf:Person'));
            const auditorName = humanAssertor?.['foaf:name'] || '';

            // 3. Wybierz odpowiedni radio button kategorii
            if (productCategory) {
                const radio = document.querySelector(`input[name="product_choice"][value="${productCategory}"]`);
                if (radio) {
                    radio.checked = true;
                }
            }

            // 4. Wypełnij pola tekstowe
            if (document.getElementById('wizard-product-name')) {
                document.getElementById('wizard-product-name').value = (productName === 'Nieznany produkt') ? '' : productName;
            }
            if (document.getElementById('wizard-product-desc')) document.getElementById('wizard-product-desc').value = productDesc;
            if (document.getElementById('wizard-auditor-name')) document.getElementById('wizard-auditor-name').value = auditorName;

            // 5. Wywołaj submit formularza aby wygenerować wiersze wymagań
            const form = document.getElementById('auditForm');
            if (form) {
                // Wywołujemy onsubmit bezpośrednio — dispatchEvent nie zawsze wyzwala onsubmit z atrybutu elementu
                if (typeof form.onsubmit === 'function') {
                    form.onsubmit(new Event('submit'));
                }
            }

            // 6. Obsłuż przełącznik Art. 19 jeśli był włączony
            if (isArt19Enabled) {
                // Szukamy switcha (jest generowany dynamicznie w kroku 5)
                const art19Switch = document.querySelector('input[role="switch"]');
                if (art19Switch && !art19Switch.checked) {
                    art19Switch.click(); // To wyzwoli całą logikę przełączania
                }
            }

            // 7. Wypełnianie wyników
            const assertions = graph.filter(it => it['@type'] === 'earl:Assertion');
            assertions.forEach(assertion => {
                const articleId = assertion['earl:test']?.['dct:identifier'];
                const outcome = assertion['earl:result']?.['earl:outcome']?.['@id'];
                const comment = assertion['earl:result']?.['dct:description'] || '';

                if (!articleId) return;

                // Asercje kart testów mają "#test-N" w identyfikatorze
                if (articleId.includes('#test-')) {
                    // Konwertuj "U.7.1.1.a#test-0" → "U.7.1.1.a--test--0" → safeTestId
                    const testDataId = articleId.replace(/#test-(\d+)$/, '--test--$1');
                    const safeTestId = testDataId.replace(/[^a-z0-9]/gi, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');

                    let testVal = '';
                    if (outcome === 'earl:passed') testVal = 'pass';
                    else if (outcome === 'earl:failed') testVal = 'fail';
                    else if (outcome === 'earl:inapplicable') testVal = 'na';

                    if (testVal) {
                        const radio = document.querySelector(`input[name="test-status-${safeTestId}"][value="${testVal}"]`);
                        if (radio) {
                            radio.checked = true;
                            // Wyzwól aktualizację stanu wizualnego i otwórz kartę
                            const card = radio.closest('.checklist-test-item');
                            if (card) {
                                card.classList.remove('is-pass', 'is-fail', 'is-na');
                                card.classList.add('is-' + testVal);
                                card.open = true;
                            }
                        }
                    }

                    const testTextarea = document.querySelector(`textarea[name="test-comment-${safeTestId}"]`);
                    if (testTextarea) testTextarea.value = comment;
                    return;
                }

                // Regular requirement-row assertion
                {
                    // Obliczyć safeArticleId tak samo jak w generateAssessmentRows()
                    const safeArticleId = articleId.replace(/[^a-z0-9]/gi, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
                    
                    // Mapowanie EARL outcome na wartości radio
                    let val = '';
                    if (outcome === 'earl:passed') val = 'compliant';
                    else if (outcome === 'earl:failed') val = 'non-compliant';
                    else if (outcome === 'earl:inapplicable') val = 'not-applicable';

                    if (val) {
                        const radio = document.querySelector(`input[name="status-${safeArticleId}"][value="${val}"]`);
                        if (radio) radio.checked = true;
                    }

                    const textarea = document.querySelector(`textarea[name="comment-${safeArticleId}"]`);
                    if (textarea) textarea.value = comment;
                }
            });

            // 8. Odśwież podsumowanie
            generateDescriptiveSummary();

            // 9. Przewiń do wyników (aby użytkownik widział wczytany arkusz)
            setTimeout(() => {
                const resultsHeader = document.getElementById('selectedProductName');
                if (resultsHeader) {
                    const header = document.querySelector('.app-header');
                    const headerOffset = header ? header.getBoundingClientRect().height : 0;
                    const top = resultsHeader.getBoundingClientRect().top + window.pageYOffset - headerOffset - 20;
                    window.scrollTo({ top, behavior: 'smooth' });
                    resultsHeader.focus({ preventScroll: true });
                }
            }, 150);

            // Powiadomienie
            let liveRegion = document.getElementById('status-message') || document.getElementById('a11y-live-region');
            if (liveRegion) {
                liveRegion.innerText = 'Wczytano stan oceny z pliku JSON.';
            }

        } catch (err) {
            console.error('Błąd podczas wczytywania pliku:', err);
            
            // Komunikat dla screen readerów
            let liveRegion = document.getElementById('status-message');
            if (liveRegion) {
                liveRegion.innerText = 'Błąd podczas wczytywania pliku: ' + err.message;
            }
            
            // Przyjazne komunikaty błędów dla typowych problemów
            let userMsg = 'Wystąpił błąd podczas wczytywania pliku.';
            if (err instanceof SyntaxError) {
                if (err.message.includes('%PDF')) {
                    userMsg = 'Nieprawidłowy format pliku. Proszę wybrać plik JSON zapisany przez aplikację, nie PDF.';
                } else {
                    userMsg = 'Plik nie jest prawidłowym plikiem JSON. Upewnij się, że został zapisany przez aplikację OZ-PAD.';
                }
            } else if (err.message) {
                userMsg = 'Błąd wczytywania: ' + err.message;
            }
            
            showToast(userMsg, 'error');
        }
    };
    reader.readAsText(file);
    // Zresetuj input, aby umożliwić ponowne wczytanie tego samego pliku
    event.target.value = '';
}

function setupWizardSave() {
    if (wizardSaveBound) return;
    wizardSaveBound = true;

    const saveBtn = document.getElementById('btn-save-wizard');
    const loadBtn = document.getElementById('btn-load-wizard');
    const spreadsheetBtn = document.getElementById('btn-download-spreadsheet');
    const glossaryBtn = document.getElementById('btn-show-glossary');
    const fileInput = document.getElementById('wizard-file-input');

    if (saveBtn) {
        saveBtn.addEventListener('click', () => {
            if (isDownloadingWizard) return;
            isDownloadingWizard = true;
            downloadWizardAssessment();
            setTimeout(() => isDownloadingWizard = false, 1000);
        });
    }

    if (loadBtn) {
        loadBtn.addEventListener('click', () => {
            // Jeśli hero jest widoczne, kliknięcie w navbarze też powinno przygotować UI
            const heroSection = document.getElementById('hero-section');
            const setupSection = document.getElementById('setup-section');
            if (heroSection && !heroSection.classList.contains('hidden')) {
                // Nie ukrywamy jeszcze hero, zrobimy to po wybraniu pliku w handleWizardFileLoad
            }
            if (fileInput) fileInput.click();
        });
    }

    if (fileInput) {
        fileInput.addEventListener('change', handleWizardFileLoad);
    }

    if (spreadsheetBtn) {
        spreadsheetBtn.addEventListener('click', () => {
            if (isDownloadingWizard) return;
            isDownloadingWizard = true;
            downloadWizardSpreadsheet(true);
            setTimeout(() => isDownloadingWizard = false, 1000);
        });
    }

     if (glossaryBtn) {
        glossaryBtn.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            showGlossary(glossaryBtn);
        });
    }

    // Obsługa Ctrl+S / Cmd+S (zapis) i Ctrl+O (wczytaj)
    document.addEventListener('keydown', (e) => {
        if ((e.ctrlKey || e.metaKey) && e.key === 's') {
            e.preventDefault();
            if (isDownloadingWizard) return;
            isDownloadingWizard = true;
            downloadWizardAssessment();
            setTimeout(() => isDownloadingWizard = false, 1000);
        } else if ((e.ctrlKey || e.metaKey) && e.key === 'o') {
            e.preventDefault();
            const loadBtn = document.getElementById('btn-load-wizard');
            if (loadBtn) loadBtn.click();
        }
    });
}

/**
 * Renderuje interaktywną kartę testu (fieldset) dla pojedynczego obiektu testu.
 * @param {string} clauseId - ID klauzuli nadrzędnej (np. "U.7.1.1.a").
 * @param {{type:string, title:string, description?:string}} testObj - Obiekt testu.
 * @param {number} testIndex - Indeks (od 0) tego testu w tablicy checklisty.
 */
function renderTestCard(clauseId, testObj, testIndex) {
    const testDataId = `${clauseId}--test--${testIndex}`;
    const safeTestId = testDataId.replace(/[^a-z0-9]/gi, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
    const title = (W.fixOrphans ? W.fixOrphans(testObj.title || '') : (testObj.title || ''));
    let descHtml = '';
    if (testObj.description) {
        let d = testObj.description;
        if (W.fixOrphans) d = W.fixOrphans(d);
        if (W.parseMarkdown) d = W.parseMarkdown(d);
        descHtml = `<div class="test-description">${d}</div>`;
    }
    return `<details class="checklist-test-item" data-test-id="${testDataId}">
        <summary class="checklist-test-summary">${title}</summary>
        ${descHtml}
        <fieldset class="checklist-test-controls" aria-label="Ocena testu: ${title}">
            <legend class="sr-only">Ocena testu: ${title}</legend>
            <div class="test-options-row">
                <label><input type="radio" name="test-status-${safeTestId}" value="pass"> Spełnione</label>
                <label><input type="radio" name="test-status-${safeTestId}" value="fail"> Niespełnione</label>
                <label><input type="radio" name="test-status-${safeTestId}" value="na"> Nie dotyczy</label>
            </div>
            <label for="test-comment-${safeTestId}">Komentarz do testu</label>
            <textarea id="test-comment-${safeTestId}" name="test-comment-${safeTestId}" placeholder="Wpisz komentarz..." aria-label="Komentarz do testu: ${title}"></textarea>
        </fieldset>
    </details>`;
}

/**
 * Renderuje kartę testu dla przeglądarki klauzul (bez formularza oceny).
 * Używa struktury z renderTestCard, ale bez opcji oceny i pola komentarza.
 */
function renderTestCardMinimal(testObj) {
    const title = (W.fixOrphans ? W.fixOrphans(testObj.title || '') : (testObj.title || ''));
    let descHtml = '';
    if (testObj.description) {
        let d = testObj.description;
        if (W.fixOrphans) d = W.fixOrphans(d);
        if (W.parseMarkdown) d = W.parseMarkdown(d);
        descHtml = `<div class="test-description">${d}</div>`;
    }
    return `<details class="checklist-test-item browser-minimal">
        <summary class="checklist-test-summary">${title}</summary>
        ${descHtml}
    </details>`;
}

function populateRadioList() {
    const fieldset = document.getElementById('productFieldset');
    const container = fieldset.querySelector('fieldset') || fieldset;
    
    // Usuń stare radio-buttony, zachowaj legend i komunikat o błędzie
    const oldRadios = container.querySelectorAll('label.product-radio-card');
    oldRadios.forEach(label => label.remove());
    
    // Filtruj produkty, by zapewnić spójną kolejność
    const entries = Object.entries(productDictionary)
        .filter(([key, name]) => name && name.trim())
        // Produkt 'default' zawsze pierwszy, reszta alfabetycznie po nazwie
        .sort((a, b) => {
            if (a[0] === 'default') return -1;
            if (b[0] === 'default') return 1;
            return a[1].localeCompare(b[1], undefined, { numeric: true });
        });

    entries.forEach(([key, name], idx) => {
        // Label pełni rolę karty-kontenera dla dostępności i obszaru kliknięcia
        const card = document.createElement('label');
        card.className = 'product-radio-card';
        
        const input = document.createElement('input');
        input.type = 'radio';
        input.name = 'product_choice';
        input.value = key;
        input.id = `prod-${idx}`;
        
        input.addEventListener('change', () => {
            const errorEl = document.getElementById('product-selection-error');
            const productFieldset = document.getElementById('productFieldset');
            errorEl.classList.add('hidden');
            errorEl.style.display = 'none';
            productFieldset.removeAttribute('aria-invalid');
            productFieldset.removeAttribute('aria-describedby');
        });
        
        const span = document.createElement('span');
        span.textContent = name;
        
        card.appendChild(input);
        card.appendChild(span);
        fieldset.appendChild(card);
    });
    
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
    
    // Dodaj nasłuchiwacze ukrywające błędy, gdy użytkownik zacznie wpisywać
    const productNameInput = document.getElementById('wizard-product-name');
    const productDescInput = document.getElementById('wizard-product-desc');
    const auditorInput = document.getElementById('wizard-auditor-name');
    
    const productNameError = document.getElementById('product-name-error');
    const productDescError = document.getElementById('product-desc-error');
    const auditorError = document.getElementById('auditor-name-error');
    
    if (productNameInput && productNameError) {
        productNameInput.addEventListener('input', () => {
            if (productNameInput.value.trim()) {
                productNameError.classList.add('hidden');
                productNameError.style.display = 'none';
                productNameInput.removeAttribute('aria-invalid');
                productNameInput.removeAttribute('aria-describedby');
            }
        });
    }
    
    if (productDescInput && productDescError) {
        productDescInput.addEventListener('input', () => {
            if (productDescInput.value.trim()) {
                productDescError.classList.add('hidden');
                productDescError.style.display = 'none';
                productDescInput.removeAttribute('aria-invalid');
                productDescInput.removeAttribute('aria-describedby');
            }
        });
    }
    
    if (auditorInput && auditorError) {
        auditorInput.addEventListener('input', () => {
            if (auditorInput.value.trim()) {
                auditorError.classList.add('hidden');
                auditorError.style.display = 'none';
                auditorInput.removeAttribute('aria-invalid');
                auditorInput.removeAttribute('aria-describedby');
            }
        });
    }
}

document.getElementById('auditForm').onsubmit = (e) => {
    e.preventDefault();
    const selectedRadio = document.querySelector('input[name="product_choice"]:checked');
    const errorEl = document.getElementById('product-selection-error');
    const firstFieldset = document.querySelector('form fieldset');
    const resultsArea = document.getElementById('resultsArea');
    
    if (!selectedRadio) {
        if (resultsArea) resultsArea.classList.add('hidden');
        
        // Pokaż komunikat błędu i oznacz grupę
        errorEl.classList.remove('hidden');
        errorEl.style.display = 'flex';
        firstFieldset.setAttribute('aria-invalid', 'true');
        firstFieldset.setAttribute('aria-describedby', 'product-selection-error');
        
        // Przewiń do elementu błędu (z uwzględnieniem stałego nagłówka) i ustaw fokus
        const header = document.querySelector('.app-header');
        const headerHeight = header ? header.getBoundingClientRect().height : 0;
        const targetTop = window.pageYOffset + errorEl.getBoundingClientRect().top - headerHeight - 20;
        
        window.scrollTo({ top: targetTop, behavior: 'smooth' });

        // Upewnij się, że element błędu może odebrać fokus, by czytnik ekranu ogłosił go raz
        errorEl.setAttribute('tabindex', '-1');
        errorEl.focus();

        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
        return;
    }
    
    errorEl.classList.add('hidden');
    errorEl.style.display = 'none';
    firstFieldset.removeAttribute('aria-invalid');
    firstFieldset.removeAttribute('aria-describedby');
    
    // Walidacja wymaganych pól
    const productNameInput = document.getElementById('wizard-product-name');
    const productDescInput = document.getElementById('wizard-product-desc');
    const auditorInput = document.getElementById('wizard-auditor-name');
    
    const productNameError = document.getElementById('product-name-error');
    const productDescError = document.getElementById('product-desc-error');
    const auditorError = document.getElementById('auditor-name-error');
    
    const productName = productNameInput?.value?.trim() || '';
    const productDesc = productDescInput?.value?.trim() || '';
    const auditor = auditorInput?.value?.trim() || '';
    
    let hasErrors = false;
    const header = document.querySelector('.app-header');
    const headerHeight = header ? header.getBoundingClientRect().height : 0;
    
    // Sprawdź nazwę produktu
    if (!productName) {
        hasErrors = true;
        productNameError.classList.remove('hidden');
        productNameError.style.display = 'flex';
        productNameInput.setAttribute('aria-invalid', 'true');
        productNameInput.setAttribute('aria-describedby', 'product-name-error');
    } else {
        productNameError.classList.add('hidden');
        productNameError.style.display = 'none';
        productNameInput.removeAttribute('aria-invalid');
        productNameInput.removeAttribute('aria-describedby');
    }
    
    // Sprawdź opis produktu
    if (!productDesc) {
        hasErrors = true;
        productDescError.classList.remove('hidden');
        productDescError.style.display = 'flex';
        productDescInput.setAttribute('aria-invalid', 'true');
        productDescInput.setAttribute('aria-describedby', 'product-desc-error');
    } else {
        productDescError.classList.add('hidden');
        productDescError.style.display = 'none';
        productDescInput.removeAttribute('aria-invalid');
        productDescInput.removeAttribute('aria-describedby');
    }
    
    // Sprawdź imię i nazwisko oceniającego
    if (!auditor) {
        hasErrors = true;
        auditorError.classList.remove('hidden');
        auditorError.style.display = 'flex';
        auditorInput.setAttribute('aria-invalid', 'true');
        auditorInput.setAttribute('aria-describedby', 'auditor-name-error');
    } else {
        auditorError.classList.add('hidden');
        auditorError.style.display = 'none';
        auditorInput.removeAttribute('aria-invalid');
        auditorInput.removeAttribute('aria-describedby');
    }
    
    if (hasErrors) {
        if (resultsArea) resultsArea.classList.add('hidden');
        
        // Określ, które pole ma błąd (pierwsze z błędem)
        let firstInputWithError = null;
        if (!productName) {
            firstInputWithError = productNameInput;
        } else if (!productDesc) {
            firstInputWithError = productDescInput;
        } else if (!auditor) {
            firstInputWithError = auditorInput;
        }
        
        const targetTop = window.pageYOffset + firstInputWithError.getBoundingClientRect().top - headerHeight - 20;
        window.scrollTo({ top: targetTop, behavior: 'smooth' });
        
        // Ustaw fokus na polu (nie na komunikacie błędu)
        firstInputWithError.focus();
        
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
        return;
    }
    
    const selectedProduct = selectedRadio.value;
    const productFullName = productDictionary[selectedProduct] || selectedProduct;

    const resultsContent = document.getElementById('resultsContent');
    resultsContent.innerHTML = `
        <h2 id="selectedProductName" tabindex="-1" style="outline: none;"><span class="selected-product-label">Arkusz dla:</span>${productFullName}</h2>
        <div id="requirementsList"></div>
    `;
    
    const list = document.getElementById('requirementsList');
    const selectedNameDisplay = document.getElementById('selectedProductName');
    
    if (resultsArea) {
        resultsArea.classList.remove('hidden');
        resultsArea.setAttribute('data-selected-product', selectedProduct);
    }

    // Aktualizuj tytuł strony po odświeżeniu raportu
    if (typeof Browser !== 'undefined' && Browser.updateTitle) {
        Browser.updateTitle(`Arkusz oceny: ${productFullName}`);
    }
    if (resultsArea) resultsArea.setAttribute('data-product-name', productFullName);
    
    let currentCategory = '';
    let art19Container = null; // Track Art. 19 container for requirements
    
    matrixData.forEach(item => {
        let productClausesRaw = item.product_mappings[selectedProduct];
        
        const isProductDefault = selectedProduct === 'default';
        const isArt19 = item.article && item.article.includes('Art. 19');
        
        // W nowym modelu productClausesRaw jest null jeśli produkt nie jest przypisany.
        // Pusty ciąg znaków ("") oznacza przypisanie tylko klauzuli legal_id.
        if (isProductDefault || productClausesRaw !== null) {
            const cleanCategory = item.category.trim();
            if (cleanCategory !== currentCategory) {
                const h3 = document.createElement('h3');
                h3.className = 'category-header';
                h3.innerHTML = `<span aria-hidden="true">${cleanCategory}</span><span class="sr-only">${expandLegal(cleanCategory)}</span>`;
                list.appendChild(h3);
                
                // Dodaj opis z przełącznikiem dla Art. 19 jeśli wymagany
                if (item.description || isArt19) {
                    const descDiv = document.createElement('div');
                    descDiv.className = 'category-description';
                    let statusAnnouncement = null; // Declare here so it's available for use later
                    
                    if (item.description) {
                        const descText = document.createElement('p');
                        descText.textContent = item.description;
                        descDiv.appendChild(descText);
                    }
                    
                    // Dodaj przełącznik toggle dla Art. 19 wewnątrz opisu
                    if (isArt19) {
                        const switchId = `art19-switch-${Math.random().toString(36).substr(2, 9)}`;
                        const label = document.createElement('label');
                        label.className = 'art19-switch-label';
                        label.setAttribute('for', switchId);
                        
                        const checkbox = document.createElement('input');
                        checkbox.type = 'checkbox';
                        checkbox.id = switchId;
                        checkbox.setAttribute('role', 'switch');
                        // Używamy natywnego stanu checked; aria-checked jest implicitnie mapowane z 'checked' dla role="switch" na input[type="checkbox"]
                        
                        const labelText = document.createElement('span');
                        labelText.textContent = 'Skontroluj wymagania artykułu 19';
                        
                        label.appendChild(checkbox);
                        label.appendChild(labelText);
                        descDiv.appendChild(label);
                        
                        // Utwórz kontener dla wymagań Art. 19 (PO opisie, nie wewnątrz)
                        art19Container = document.createElement('div');
                        art19Container.className = 'art19-requirements-container';
                        art19Container.style.display = 'none';
                        art19Container.setAttribute('data-art19-container', 'true');
                        
                        // Utwórz ogłoszenie statusu dla czytników ekranu
                        statusAnnouncement = document.createElement('div');
                        statusAnnouncement.setAttribute('role', 'status');
                        statusAnnouncement.setAttribute('aria-live', 'polite');
                        statusAnnouncement.setAttribute('aria-atomic', 'true');
                        statusAnnouncement.className = 'sr-only';
                        statusAnnouncement.dataset.art19Status = switchId;
                        
                        // Zachowaj referencję na checkbox, by była dostępna w obsłudze zdarzeń
                        checkbox.dataset.art19ContainerId = switchId;
                        
                        // Toggle handler
                        checkbox.addEventListener('change', (e) => {
                            const container = list.querySelector(`[data-art19-container="true"]`);
                            const status = list.querySelector(`[data-art19-status="${switchId}"]`);
                            if (container && status) {
                                if (e.target.checked) {
                                    container.style.display = 'block';
                                    status.textContent = 'Załadowano listę wymagań dla artykułu 19';
                                } else {
                                    container.style.display = 'none';
                                    status.textContent = 'Ukryto listę wymagań dla artykułu 19';
                                }
                            }
                        });
                    }
                    
                    list.appendChild(descDiv);
                    
                    // Dodaj ogłoszenie statusu i kontener po opisie (dla Art. 19)
                    if (isArt19 && art19Container && statusAnnouncement) {
                        list.appendChild(statusAnnouncement);
                        list.appendChild(art19Container);
                    }
                }
                
                currentCategory = cleanCategory;
            }

            // Pomocnik do renderowania list w bieżącym zakresie
            const renderBlocksFromDictionary = (arr, clauseId = '') => {
                if (!arr || arr.length === 0) return '';

                // Rozdziel łańcuchy i obiekty testowe; obiekty testowe renderuj jako interaktywne karty
                const parts = [];
                let stringBuf = [];
                let testItemIndex = 0;

                const flushStrings = () => {
                    if (stringBuf.length === 0) return;
                    let content = stringBuf.join('\n');
                    if (W.fixOrphans) content = W.fixOrphans(content);
                    if (W.parseMarkdown) content = W.parseMarkdown(content);
                    const trimmed = content.trim();
                    if (trimmed && !trimmed.startsWith('<h') && !trimmed.startsWith('<ul') && !trimmed.startsWith('<ol') && !trimmed.startsWith('<p')) {
                        parts.push(`<p>${content}</p>`);
                    } else {
                        parts.push(content);
                    }
                    stringBuf = [];
                };

                arr.forEach((item, idx) => {
                    if (item && typeof item === 'object' && item.type === 'test') {
                        flushStrings();
                        parts.push(renderTestCard(clauseId, item, testItemIndex));
                        testItemIndex++;
                    } else {
                        stringBuf.push(String(item));
                    }
                });
                flushStrings();

                return parts.join('\n');
            };

            const article = document.createElement('article');
            article.className = 'requirement-row';
            article.tabIndex = -1;
            article.setAttribute('aria-label', `Wymaganie: ${item.article} — ${item.requirement}`);
            const safeArticleId = item.article.replace(/[^a-z0-9]/gi, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
            
            if (isProductDefault && (!productClausesRaw || !productClausesRaw.trim())) {
                // Agregacja wszystkich klauzul z product_mappings jako fallback
                const allClauses = Object.values(item.product_mappings || {})
                    .join(';')
                    .split(';')
                    .map(c => c.trim())
                    .filter(Boolean);
                productClausesRaw = [...new Set(allClauses)].join('; ');
            }

            const clauses = (productClausesRaw || '').split(';').map(c => c.trim()).filter(c => c);
            
            // Automatycznie dodaj klauzulę prawną z m.legal_id jeśli istnieje
            if (item.legal_id && !clauses.includes(item.legal_id)) {
                clauses.unshift(item.legal_id);
            }

            const legalIds = [...new Set(clauses.filter(c => c.startsWith('U.') || c.startsWith('A')))];
            const cClauses = clauses.filter(c => c.startsWith('C.') && dictionaryData[c]);

            // Renderowanie "Jak to rozumieć?" (procedury)
            const procedureHtml = legalIds.map(id => {
                const data = dictionaryData[id.trim()];
                if (!data || !data.procedure || data.procedure.length === 0) return '';
                return renderBlocksFromDictionary(data.procedure);
            }).join('').trim();

            // Renderowanie "Jak sprawdzić?" (checklisty)
            const checklistHtml = legalIds.map(id => {
                const data = dictionaryData[id.trim()];
                if (!data || !data.checklist || data.checklist.length === 0) return '';
                
                return `
                <div class="detailed-checklist-container">
                    ${renderBlocksFromDictionary(data.checklist, id.trim())}
                </div>`;
            }).join('').trim();

            // Renderowanie warunków wstępnych
            const preconditionsHtml = legalIds.map(id => {
                const data = dictionaryData[id.trim()];
                if (!data || !data.preconditions || data.preconditions.length === 0) return '';
                return renderBlocksFromDictionary(data.preconditions);
            }).join('').trim();

            const grouped = {};
            cClauses.forEach(c => {
                const prefixMatch = c.match(/^(C\.\d+)/);
                const prefix = prefixMatch ? prefixMatch[0] : 'Inne';
                if (!grouped[prefix]) grouped[prefix] = [];
                grouped[prefix].push(c);
            });

            const cHtml = Object.keys(grouped).sort((a, b) => {
                const numA = parseInt(a.match(/\d+/)[0]);
                const numB = parseInt(b.match(/\d+/)[0]);
                return numA - numB;
            }).map(prefix => `
                <section class="clause-group">
                    <h5 class="clause-group-title">${chapterNames[prefix] || prefix}</h5>
                    ${grouped[prefix].sort((a, b) => a.localeCompare(b, undefined, { numeric: true })).map(c => {
                const clauseData = (dictionaryData && dictionaryData[c]) ? dictionaryData[c] : null;
                const clauseTitle = clauseData && clauseData.title ? clauseData.title.replace(/&nbsp;|\u00A0/g, ' ') : '';
                const cleanTitle = stripNumbering(clauseTitle);
                const ariaLabelSafe = `${c}${cleanTitle ? ' ' + cleanTitle : ''} - otwórz szczegóły klauzuli`.replace(/"/g, '&quot;');
                return `<button class="clause-tag" data-clause-id="${c}" onclick="showClause('${c}', this)" aria-label="${ariaLabelSafe}">
                    <span class="clause-tag-id">${c}</span>
                    <span class="clause-tag-title">${cleanTitle}</span>
                </button>`;
            }).join(' ')}
                </section>
            `).join('');

            article.innerHTML = `
                <h4 class="requirement-id">
                    <span aria-hidden="true">${item.article}</span>
                    <span class="sr-only">${expandLegal(item.article)}</span>
                </h4>
                
                <p class="requirement-text">${W.parseMarkdown ? W.parseMarkdown(item.requirement) : item.requirement}</p>
                
                ${preconditionsHtml ? `
                <div class="interpretation-area" role="region" aria-labelledby="preconditions-header-${safeArticleId}">
                    <h4 class="u-interpretation-header" id="preconditions-header-${safeArticleId}">
                        Warunki wstępne
                        <span class="sr-only"> dla ${expandLegal(item.article)}</span>
                    </h4>
                    <section class="u-interpretation">${preconditionsHtml}</section>
                </div>` : ''}
                
                ${procedureHtml ? `
                <div class="interpretation-area" role="region" aria-labelledby="procedure-header-${safeArticleId}">
                    <h4 class="u-interpretation-header" id="procedure-header-${safeArticleId}">
                        Jak to rozumieć?
                        <span class="sr-only"> dla ${expandLegal(item.article)}</span>
                    </h4>
                    <section class="u-interpretation">${procedureHtml}</section>
                </div>` : ''}

                ${checklistHtml ? `
                <div class="interpretation-area" role="region" aria-labelledby="how-to-test-header-${safeArticleId}">
                    <h4 class="u-interpretation-header" id="how-to-test-header-${safeArticleId}">
                        Jak sprawdzić?
                        <span class="sr-only"> dla ${expandLegal(item.article)}</span>
                    </h4>
                    <section class="u-interpretation">${checklistHtml}</section>
                </div>` : ''}

                ${cHtml ? `
                <section class="technical-area">
                    <details class="technical-details">
                        <summary class="technical-summary">
                            <h4 class="technical-title">
                                Szczegółowe testy techniczne (EN 301 549) dla ${expandLegal(item.article)}
                            </h4>
                        </summary>
                        <section class="technical-section">
                            ${cHtml}
                        </section>
                    </details>
                </section>` : ''}
                
                <section class="assessment-section">
                    <fieldset aria-describedby="test-summary-${safeArticleId}">
                        <legend>Ocena spełnienia wymagania dla ${item.article}</legend>
                        <div class="test-summary-assessment" id="test-summary-${safeArticleId}"></div>
                        
                        <label for="status-compliant-${safeArticleId}">
                            <input type="radio" id="status-compliant-${safeArticleId}" name="status-${safeArticleId}" value="compliant">
                            Spełnione
                        </label>
                        
                        <label for="status-non-compliant-${safeArticleId}">
                            <input type="radio" id="status-non-compliant-${safeArticleId}" name="status-${safeArticleId}" value="non-compliant">
                            Niespełnione
                        </label>
                        
                        <label for="status-na-${safeArticleId}">
                            <input type="radio" id="status-na-${safeArticleId}" name="status-${safeArticleId}" value="not-applicable">
                            Nie dotyczy
                        </label>
                    </fieldset>
                    
                    <label for="comment-${safeArticleId}">Komentarz</label>
                    <textarea id="comment-${safeArticleId}" name="comment-${safeArticleId}"></textarea>
                </section>
            `;
            
            // Dla Art. 19 dodaj do kontenera, w pozostałych przypadkach do listy
            const targetContainer = isArt19 && art19Container ? art19Container : list;
            targetContainer.appendChild(article);
            
            // Oznacz linki otwierające się w nowej karcie (wizualnie CSS + tekst dla SR)
            indicateNewTabLinks(article);
            // Upewnij się, że przyciski clause-tag w dynamicznie generowanym article są wzbogacone
            try { enhanceClauseTagsWizard(article); } catch (e) { /* ignore */ }
        }
    });
    
    document.getElementById('resultsArea').classList.remove('hidden');
    
    // Event delegation: aktualizuj podsumowanie testów przy każdej zmianie oceny testu
    list.addEventListener('change', (e) => {
        if (e.target.type === 'radio' && e.target.name && e.target.name.startsWith('test-status-')) {
            const row = e.target.closest('.requirement-row');
            if (row) updateTestSummaryForRow(row);
        }
    });
    
    // Ogłoś zakończenie generowania technologiom wspomagającym
    const announcement = document.getElementById('generation-announcement');
    announcement.textContent = "Wygenerowano arkusz dla: " + productFullName;
    
    // Zawsze generuj pustą kartę podsumowania na starcie
    generateDescriptiveSummary(true);

    // Przenieś fokus i przewiń do nagłówka wyników
    setTimeout(() => {
        // Uwzględnij wysokość stałego nagłówka, by tytuł nie znikał za nim
        const header = document.querySelector('.app-header');
        const headerOffset = header ? header.getBoundingClientRect().height : 0;
        const top = selectedNameDisplay.getBoundingClientRect().top + window.pageYOffset - headerOffset - 8;
        window.scrollTo({ top, behavior: 'smooth' });
        // Ustaw fokus po przewinęciu; preventScroll zapobiega skokowi
        setTimeout(() => { selectedNameDisplay.focus({ preventScroll: true }); }, 100);
        // Wyczyść ogłoszenie po odczytaniu, by można było wyzwolić ponownie
        setTimeout(() => { announcement.textContent = ""; }, 800);
    }, 50);
};

// --- Blokada otwierania modalu ---
let isModalOpening = false;

function getFocusableElements(modal) {
    if (!modal) return [];
    const selector = [
        'a[href]',
        'button:not([disabled])',
        'input:not([disabled]):not([type="hidden"])',
        'summary',
        'select:not([disabled])',
        'textarea:not([disabled])',
        '[tabindex]:not([tabindex="-1"])'
    ].join(',');

    return Array.from(modal.querySelectorAll(selector)).filter(el => {
        if (el.hasAttribute('hidden')) return false;
        if (el.getAttribute('aria-hidden') === 'true') return false;
        return el.getClientRects().length > 0;
    });
}

function deactivateModalFocusTrap() {
    if (activeModalTrapCleanup) {
        activeModalTrapCleanup();
        activeModalTrapCleanup = null;
    }
}

function activateModalFocusTrap(modal) {
    deactivateModalFocusTrap();
    if (!modal) return;

    const onKeyDown = (e) => {
        if (e.key !== 'Tab' || !modal.open) return;

        const focusable = getFocusableElements(modal);
        if (focusable.length === 0) {
            e.preventDefault();
            if (modal.tabIndex < 0) modal.tabIndex = -1;
            modal.focus();
            return;
        }

        const first = focusable[0];
        const last = focusable[focusable.length - 1];
        const active = document.activeElement;

        if (e.shiftKey) {
            if (active === first || !modal.contains(active)) {
                e.preventDefault();
                last.focus();
            }
        } else if (active === last || !modal.contains(active)) {
            e.preventDefault();
            first.focus();
        }
    };

    const onFocusIn = (e) => {
        if (!modal.open) return;
        if (modal.contains(e.target)) return;

        const focusable = getFocusableElements(modal);
        const target = focusable[0] || modal;
        if (target === modal && modal.tabIndex < 0) modal.tabIndex = -1;
        target.focus();
    };

    modal.addEventListener('keydown', onKeyDown);
    document.addEventListener('focusin', onFocusIn);

    activeModalTrapCleanup = () => {
        modal.removeEventListener('keydown', onKeyDown);
        document.removeEventListener('focusin', onFocusIn);
    };
}

window.showGlossary = (triggerEl = null) => {
    if (isModalOpening) return;

    const modal = document.getElementById('glossaryModal');
    if (!modal || modal.open) return;

    isModalOpening = true;
    setTimeout(() => { isModalOpening = false; }, 500);

    const body = document.getElementById('glossaryBody');

    const fullHtml = `
        <div class="glossary-search-wrap">
            <label for="glossarySearch" class="sr-only">Wyszukaj na liście:</label>
            <input type="search" id="glossarySearch" placeholder="Szukaj pojęcia..." autocomplete="off" autofocus>
        </div>
        <p class="glossary-intro">W tym słowniku znajdziesz wyjaśnienia kluczowych pojęć używanych w aplikacji OZ-PAD.</p>
        <div id="glossaryList" role="region" aria-label="Lista haseł słownika" aria-busy="true"></div>
    `;
    
    body.innerHTML = fullHtml;

    if (typeof lucide !== 'undefined' && lucide.createIcons) {
        lucide.createIcons({ root: body });
    }

    lastModalTrigger = triggerEl;

    if (!modal.open) {
        document.documentElement.classList.add('modal-is-open');
        modal.showModal();
        activateModalFocusTrap(modal);
    }
    
    const searchInput = body.querySelector('#glossarySearch');
    const listContainer = body.querySelector('#glossaryList');

    if (searchInput) {
        // Poczekaj na układ dialogu, następnie przenieś fokus i przewiń do pola wyszukiwania.
        requestAnimationFrame(() => {
            requestAnimationFrame(() => {
                if (!modal.open) return;
                searchInput.focus();
                searchInput.scrollIntoView({ block: 'center', inline: 'nearest' });
            });
        });
    }

    const terms = Object.keys(glossaryData).sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
    const glossaryHtml = terms.map(term => {
        let def = glossaryData[term];
        if (W.fixOrphans) def = W.fixOrphans(def);
        if (W.parseMarkdown) def = W.parseMarkdown(def);
        return `
            <details class="glossary-item">
                <summary>${term}</summary>
                <div class="glossary-item-content">${def}</div>
            </details>
        `;
    }).join('');

    // Renderuj dużą listę słownika po otwarciu modalu i przekazaniu focusu.
    setTimeout(() => {
        if (!modal.open || !listContainer) return;
        listContainer.innerHTML = glossaryHtml;
        listContainer.setAttribute('aria-busy', 'false');
    }, 60);
    
    if (searchInput) {
        // Filtruj hasła słownika w miarę wpisywania.
        searchInput.addEventListener('input', () => {
            const q = searchInput.value.toLowerCase().trim();
            const items = listContainer.querySelectorAll('.glossary-item');
            items.forEach(item => {
                const termText = item.querySelector('summary')?.textContent?.toLowerCase() || '';
                const defText = item.querySelector('.glossary-item-content')?.textContent?.toLowerCase() || '';
                const index = `${termText} ${defText}`;
                const visible = index.includes(q);
                item.style.display = visible ? 'block' : 'none';
                if (!visible) item.removeAttribute('open');
            });
        });

        // Klawiaturowa ścieżka do treści: strzałka w dół z wyszukiwania przenosi fokus do pierwszego widocznego hasła.
        searchInput.addEventListener('keydown', (e) => {
            if (e.key === 'ArrowDown' && listContainer) {
                e.preventDefault();
                const firstVisibleSummary = listContainer.querySelector('.glossary-item:not([style*="display: none"]) summary');
                if (firstVisibleSummary) firstVisibleSummary.focus();
            }
        });
    }
};

window.showClause = (id, triggerEl = null) => {
    if (isModalOpening) return;
    isModalOpening = true;
    setTimeout(() => { isModalOpening = false; }, 500);

    const modal = document.getElementById('clauseModal');
    const body = document.getElementById('clauseBody');

    lastModalTrigger = triggerEl;
    const data = (window.dictionaryData && window.dictionaryData[id.trim()]) ? window.dictionaryData[id.trim()] : (typeof dictionaryData !== 'undefined' ? dictionaryData[id.trim()] : null);

    if (data) {
        const renderListBlocks = (arr) => {
            if (!arr || arr.length === 0) return '<p><i>Brak danych</i></p>';
            const stringified = arr.map(item => {
                if (item && typeof item === 'object' && item.type === 'test') {
                    let text = `**${item.title || ''}**`;
                    if (item.description) text += `: ${item.description}`;
                    return text;
                }
                return item;
            });
            let content = stringified.join('\n');
            if (W.fixOrphans) content = W.fixOrphans(content);
            if (W.parseMarkdown) content = W.parseMarkdown(content);
            const trimmed = content.trim();
            if (trimmed && !trimmed.startsWith('<h') && !trimmed.startsWith('<ul') && !trimmed.startsWith('<ol') && !trimmed.startsWith('<p')) {
                return `<p>${content}</p>`;
            }
            return content;
        };

        const renderCriteria = (form) => {
            if (!form || !form.inputs) return '<p><i>Brak określonych kryteriów.</i></p>';
            return form.inputs.map(i => {
                let text = (W.fixOrphans || (s=>s))(i.label);
                if (W.parseMarkdown) text = W.parseMarkdown(text);
                return `<p><strong>${i.value.toUpperCase()}:</strong> ${text}</p>`;
            }).join('');
        };

        const renderClauseSection = (sectionTitle, content, extraClass = '') => {
            const className = ['clause-section', extraClass].filter(Boolean).join(' ');
            return `
                <details class="${className}" aria-busy="true">
                    <summary class="browser-card-section-title" tabindex="0">${sectionTitle}</summary>
                    <div class="section-content">${content}</div>
                </details>
            `;
        };

        const cleanTitle = stripNumbering(data.title.replace(/&nbsp;/g, ' '));
        const visualTitle = (W.fixOrphans || (s=>s))(cleanTitle);

        const visualIdEl = document.getElementById('clauseModalVisualId');
        const visualTextEl = document.getElementById('clauseModalVisualText');
        if (visualIdEl) visualIdEl.textContent = data.id;
        if (visualTextEl) visualTextEl.textContent = visualTitle;

        modal.setAttribute('aria-label', `Szczegóły klauzuli ${data.id} ${visualTitle}`);
        
        const closeBtn = document.getElementById('clauseCloseButton');
        if (closeBtn) {
            closeBtn.tabIndex = -1;
            closeBtn.setAttribute('aria-hidden', 'true');
            closeBtn.setAttribute('disabled', '');
        }

        const contentHtml = `
            ${renderClauseSection('Warunki wstępne', renderListBlocks(data.preconditions))}
            ${renderClauseSection((id.trim().startsWith('U.') || id.trim().startsWith('A')) ? 'Jak to rozumieć?' : 'Procedura', renderListBlocks(data.procedure))}
            ${renderClauseSection(`Kryteria oceny (${data.evaluation})`, renderCriteria(data.form), 'criteria-section')}
            ${renderClauseSection('Jak to sprawdzić?', data.checklist && data.checklist.length > 0 ? data.checklist.map(item => {
                if (item && typeof item === 'object' && item.type === 'test') return renderTestCardMinimal(item);
                let text = (W.fixOrphans || (s=>s))((W.stripNumbering || (s=>s))(String(item)));
                if (W.parseMarkdown) text = W.parseMarkdown(text);
                return `<p class="checklist-item">${text}</p>`;
            }).join('') : `<p><i>Brak danych</i></p>`, 'how-to-check-section')}
            ${data.notes && data.notes.length > 0 ? renderClauseSection('Uwagi', renderListBlocks(data.notes)) : ''}
        `;

        body.setAttribute('aria-busy', 'true');
        body.innerHTML = '<div id="clauseLoading" aria-live="polite" style="padding: 1rem; text-align: center;"><i>Wczytywanie...</i></div>';

        setTimeout(() => {
            if (!modal.open) return;
            const loading = body.querySelector('#clauseLoading');
            if (loading) loading.remove();

            body.innerHTML = contentHtml;
            body.removeAttribute('aria-busy');
            body.querySelectorAll('.clause-section').forEach(s => s.setAttribute('aria-busy', 'false'));
            if (typeof lucide !== 'undefined' && lucide.createIcons) {
                lucide.createIcons({ root: body });
            }
            indicateNewTabLinks(body);

            const firstSummary = body.querySelector('summary');
            if (firstSummary) {
                requestAnimationFrame(() => {
                    requestAnimationFrame(() => {
                        if (!modal.open) return;
                        firstSummary.focus();
                        firstSummary.scrollIntoView({ block: 'nearest', inline: 'nearest' });
                        if (closeBtn) {
                            closeBtn.removeAttribute('aria-hidden');
                            closeBtn.removeAttribute('disabled');
                            closeBtn.tabIndex = 0;
                        }
                    });
                });
            } else if (closeBtn) {
                closeBtn.removeAttribute('aria-hidden');
                closeBtn.removeAttribute('disabled');
                closeBtn.tabIndex = 0;
            }
        }, 80);
    } else {
        const visualIdEl = document.getElementById('clauseModalVisualId');
        const visualTextEl = document.getElementById('clauseModalVisualText');
        if (visualIdEl) visualIdEl.textContent = id;
        if (visualTextEl) visualTextEl.textContent = 'Nie odnaleziono szczegółów klauzuli';
        body.innerHTML = `<p>Nie odnaleziono szczegółów dla klauzuli: ${id}</p>`;
    }

    if (!modal.open) {
        document.documentElement.classList.add('modal-is-open');
        modal.showModal();
        activateModalFocusTrap(modal);
    }
    body.scrollTop = 0;
};

const handleCloseModal = (modalId) => {
    const modal = document.getElementById(modalId || 'clauseModal');
    deactivateModalFocusTrap();
    if (modal) {
        if (modal.id === 'clauseModal') {
            const visualIdEl = document.getElementById('clauseModalVisualId');
            const visualTextEl = document.getElementById('clauseModalVisualText');
            if (visualIdEl) visualIdEl.textContent = '';
            if (visualTextEl) visualTextEl.textContent = '';
        }
        modal.close();
        document.documentElement.classList.remove('modal-is-open');
    }
    if (lastModalTrigger) {
        lastModalTrigger.focus();
        lastModalTrigger = null;
    }
};

document.addEventListener('DOMContentLoaded', () => {
    const clauseModalEl = document.getElementById('clauseModal');
    if (clauseModalEl) {
        clauseModalEl.onclick = (e) => { if (e.target.nodeName === 'DIALOG') handleCloseModal('clauseModal'); };
        clauseModalEl.oncancel = (e) => { e.preventDefault(); handleCloseModal('clauseModal'); };
    }
    const glossaryModalEl = document.getElementById('glossaryModal');
    if (glossaryModalEl) {
        glossaryModalEl.onclick = (e) => { if (e.target.nodeName === 'DIALOG') handleCloseModal('glossaryModal'); };
        glossaryModalEl.oncancel = (e) => { e.preventDefault(); handleCloseModal('glossaryModal'); };
    }
    document.addEventListener('change', (e) => {
        const radio = e.target;
        if (!radio.matches('.checklist-test-item input[type="radio"]')) return;
        const card = radio.closest('.checklist-test-item');
        if (card) {
            card.classList.remove('is-pass', 'is-fail', 'is-na');
            card.classList.add('is-' + radio.value);
        }
    });
});

// --- Pomocniki dostępności dla przycisków ikon (uproszczona wersja właściwa dla Wizarda) ---
function placeIconLabelWizard(buttonEl, labelEl) {
    if (!buttonEl || !labelEl) return;

    // Zresetuj poprzednie pozycjonowanie i klasy
    labelEl.classList.remove('icon-label--left','icon-label--right');
    labelEl.style.left = '';
    labelEl.style.right = '';
    labelEl.style.top = '';
    labelEl.style.maxWidth = '';
    labelEl.style.whiteSpace = 'nowrap';

    // Wymuś przeliczenie układu, by pomiary były wiarygodne
    void labelEl.offsetWidth;

    const brect = buttonEl.getBoundingClientRect();
    const labelRect = labelEl.getBoundingClientRect();
    const vw = Math.max(document.documentElement.clientWidth || 0, window.innerWidth || 0);

    // Preferowane: wyśrodkowanie nad przyciskiem, jeśli to możliwe
    const centerLeft = brect.left + (brect.width / 2) - (labelRect.width / 2);
    if (centerLeft >= 8 && (centerLeft + labelRect.width) <= (vw - 8)) {
        labelEl.style.left = `${centerLeft}px`;
    } else if (brect.left < vw / 2) {
            // Wyrównanie do prawej krawędzi przycisku (lewa strona)
            const leftPx = Math.min(brect.left + 8, vw - labelRect.width - 8);
            labelEl.style.left = `${leftPx}px`;
            labelEl.classList.add('icon-label--left');
        } else {
            // Wyrównanie do lewej krawędzi przycisku (prawa strona)
            const leftPx = Math.max(brect.right - labelRect.width - 8, 8);
            labelEl.style.left = `${leftPx}px`;
            labelEl.classList.add('icon-label--right');
        }

        // Pozycja pionowa: preferuj pod przyciskiem, przesuń powyżej jeśli wychodzi poza viewport
        const viewportH = Math.max(document.documentElement.clientHeight || 0, window.innerHeight || 0);
        let topPx = brect.bottom + 8;
        if ((topPx + labelRect.height + 8) > viewportH) {
            // przesuń powyżej
            topPx = Math.max(brect.top - labelRect.height - 8, 8);
        }
        labelEl.style.top = `${topPx}px`;
        labelEl.style.transform = 'translateY(0)';

        // Jeśli etykieta jest szersza niż viewport, zezwól na zawijanie i ogranicz szerokość
        if (labelRect.width > (vw - 16)) {
            labelEl.style.maxWidth = `${vw - 16}px`;
            labelEl.style.whiteSpace = 'normal';
        }
    }

function updateThemeToggleButtonsWizard(theme) {
    try {
        const lang = document.documentElement.lang || 'pl';
        const modeTo = theme === 'dark' ? 'jasny' : 'ciemny';
        const actionText = (lang && lang.startsWith('pl')) ? `Przełącz motyw na ${modeTo}` : `Toggle theme to ${modeTo}`;
        document.querySelectorAll('button[onclick*="toggleTheme"]').forEach(el => {
            el.setAttribute('aria-label', actionText);
            const labelEl = el.querySelector('.icon-label');
            if (labelEl) {
                // Widoczna etykieta pokazuje pełny tekst akcji przy hover (domyślnie ukryta przez CSS); aria-label zachowuje akcję dla SR
                labelEl.textContent = actionText;
                placeIconLabelWizard(el, labelEl);
            }
        });
        // Ogłoś zmianę dla czytników ekranu (użyj generation-announcement jeśli dostępny)
        const announcement = document.getElementById('generation-announcement');
        if (announcement) {
            announcement.textContent = (lang && lang.startsWith('pl')) ? `Ustawiono motyw: ${theme === 'dark' ? 'ciemny' : 'jasny'}` : `Theme set: ${theme}`;
            setTimeout(() => { announcement.textContent = ''; }, 1200);
        }
    } catch (e) { /* ignore */ }
}

// Repozycjonuj etykiety przy zmianie rozmiaru okna
window.addEventListener('resize', () => {
    document.querySelectorAll('.icon-label').forEach(label => {
        const btn = label.parentElement;
        placeIconLabelWizard(btn, label);
    });
});


// Oznacza linki otwierające się w nowej karcie (dostępność i bezpieczeństwo):
// - Marker wizualny (pseudo-element) obsługiwany przez CSS (wizard.css)
// - Dla czytników ekranu dodajemy ukryty węzeł tekstowy i upewniamy się, że rel zawiera noopener/noreferrer
function indicateNewTabLinks(container = document) {
    try {
        const links = (container && container.querySelectorAll) ? container.querySelectorAll('a[target="_blank"]') : [];
        links.forEach(a => {
            // Pomiń elementy nawigacji i przyciski
            if (a.closest('nav') || a.classList.contains('nav-item') || a.getAttribute('role') === 'button') return;

            // Upewnij się, że rel zawiera noopener i noreferrer dla bezpieczeństwa
            try {
                const relParts = (a.getAttribute('rel') || '').split(/\s+/).filter(Boolean);
                ['noopener','noreferrer'].forEach(x => { if (!relParts.includes(x)) relParts.push(x); });
                if (relParts.length) a.setAttribute('rel', relParts.join(' '));
            } catch (e) { /* ignore */ }

            if (!a.dataset.newTabIndicator) {
                const sr = document.createElement('span');
                sr.className = 'sr-only';
                sr.textContent = (document.documentElement.lang && document.documentElement.lang.startsWith('pl')) ? ' (otworzy się w nowej karcie)' : ' (opens in a new tab)';
                a.appendChild(sr);
                a.dataset.newTabIndicator = '1';
            }

            // Dodaj ikonę Lucide jako wizualny wskaźnik, jeśli jeszcze nie ma
            if (!a.querySelector('.external-link-icon')) {
                const iconWrap = document.createElement('span');
                iconWrap.className = 'external-link-icon';
                iconWrap.setAttribute('aria-hidden', 'true');
                iconWrap.innerHTML = '<i data-lucide="external-link" aria-hidden="true"></i>';
                a.appendChild(iconWrap);
                try { if (window.lucide && typeof window.lucide.createIcons === 'function') window.lucide.createIcons(); } catch (e) { /* ignore */ }
            }
            // Wzbogać też przyciski clause-tag wewnątrz kontenera (jeśli są)
            try { enhanceClauseTagsWizard(container); } catch (e) { /* ignore */ }
        });
    } catch (e) { /* ignore */ }
}

// Uruchom raz po załadowaniu DOM, by oznaczyć statyczną treść
document.addEventListener('DOMContentLoaded', () => { indicateNewTabLinks(document); enhanceClauseTagsWizard(document); });


// Wzbogaca przyciski clause-tag: zapewnia etykiety dostępne dla czytników ekranu (etykiety wizualne są inline)
function enhanceClauseTagsWizard(container = document) {
    // Etykiety są generowane inline w nowoczesnej wersji OZ-PAD (WCAG 1.4.13),
    // by uniknąć migotania przy wielu małych tagach.
    try {
        const els = (container && container.querySelectorAll) ? container.querySelectorAll('.clause-tag') : [];
        els.forEach(btn => {
            if (btn.dataset.enhancedClauseTag) return;
            const clauseId = btn.dataset.clauseId ? btn.dataset.clauseId : btn.textContent.split('\n')[0].trim();
            
            const data = (window && window.dictionaryData && window.dictionaryData[clauseId]) ? window.dictionaryData[clauseId] : (dictionaryData && dictionaryData[clauseId] ? dictionaryData[clauseId] : null);
            if (data && data.title) {
                const titleClean = stripNumbering(data.title.replace(/&nbsp;|\u00A0/g, ' '));
                
                // Upewnij się, że aria-label zawiera nazwę klauzuli dla czytników ekranu
                const articleRef = btn.getAttribute('aria-label') || '';
                if (!articleRef.includes(titleClean)) {
                    const newLabel = articleRef ? `${articleRef}: ${titleClean}` : `Klauzula ${clauseId}: ${titleClean}`;
                    btn.setAttribute('aria-label', newLabel);
                }
            }

            btn.dataset.enhancedClauseTag = '1';
        });
    } catch (e) { /* ignore */ }
}


(function applySavedTheme() {
    try {
        const saved = localStorage.getItem('theme');
        if (saved) {
            document.documentElement.setAttribute('data-theme', saved);
            const icon = document.getElementById('theme-icon');
            if (icon) {
                icon.setAttribute('data-lucide', saved === 'dark' ? 'moon' : 'sun');
                if (window.lucide) window.lucide.createIcons();
            }
            if (typeof updateThemeToggleButtonsWizard === 'function') updateThemeToggleButtonsWizard(saved);
        }
    } catch (e) { /* ignore */ }
})();

document.getElementById('clauseModal').onclose = () => {
    document.documentElement.classList.remove('modal-is-open');
};
document.getElementById('glossaryModal').onclose = () => {
    document.documentElement.classList.remove('modal-is-open');
};

// Initialize
init();

/**
 * Obsługa automatycznego ukrywania/pokazywania belki przy przewijaniu (WCAG scroll-hide technique)
 */
function setupHeaderScrollHandler() {
    let lastScrollY = window.pageYOffset;
    const header = document.querySelector('.app-header');
    if (!header) return;

    window.addEventListener('scroll', () => {
        const currentScrollY = window.pageYOffset;
        
        // Nie ukrywaj na samej górze lub gdy przewijanie jest minimalne
        if (currentScrollY < 100) {
            header.classList.remove('header-hidden');
            lastScrollY = currentScrollY;
            return;
        }

        // Ukryj przy przewijaniu w dół, pokaż przy przewijaniu w górę
        if (currentScrollY > lastScrollY && !header.classList.contains('header-hidden')) {
            header.classList.add('header-hidden');
        } else if (currentScrollY < lastScrollY && header.classList.contains('header-hidden')) {
            header.classList.remove('header-hidden');
        }
        
        lastScrollY = currentScrollY;
    }, { passive: true });
}
